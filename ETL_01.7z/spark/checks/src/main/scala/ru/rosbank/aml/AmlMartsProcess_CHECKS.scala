package ru.rosbank.aml

import com.typesafe.config.{Config, ConfigFactory}
import java.io.File
import java.sql.{Date, Timestamp}
import java.time.format.DateTimeFormatter
import java.time.{LocalDate, LocalDateTime, ZoneId}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.expressions.Window
import scala.collection.mutable.{ListBuffer, Map}
import scala.util.control.Breaks.break
import scala.util.{Try, Success, Failure}

import collection.JavaConversions._

object AmlMartsProcess_CHECKS {

  var confChecks: Config = _

  val argsList = List("launch_id", "db_config_checks")

  // Map with system variables
  var systemVarsMap = Map.empty[String, String]

  // error codes
  val ERR_CODE_STR = "-1"
  val ERR_CODE_NUM = new java.math.BigDecimal(ERR_CODE_STR)
  val ERR_CODE_DATE = toDate((LocalDate.parse("1900-01-01", DateTimeFormatter.ofPattern("yyyy-MM-dd"))))
  val ERR_CODE_DT = toTimestamp(LocalDateTime.parse("1900-01-01 00:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))

  val colVal = "COUNT_VAL"
  val colNull = "COUNT_NULL"
  val unitName = "unit"


  // add system variable to Map
  def addSystemVar(sys_name: String, sys_val: String): Unit = {
    systemVarsMap += (sys_name -> sys_val)
    out(s"INFO: Added system variable: $sys_name = $sys_val")
  }

  // select only column and unit
  def colSelect(df: DataFrame, colName: String): DataFrame = {
    df.select(colName, unitName)
  }

  // add table name, column name and column type
  def addInfo(colName: String, colType: String)(df:DataFrame): DataFrame = {
    df.withColumn("columnName", lit(colName))
      .withColumn("type", lit(colType))
  }

  // return boolean Column (true - return column)
  def getFilter(c: Column, dt: DataType, colName: String, colType: String): Column = {
    dt match {
      case dt: StringType =>
        colType match {
          case `colVal` => col(colName) =!= ERR_CODE_STR && col(colName).isNotNull
          case `colNull` => col(colName) === ERR_CODE_STR || col(colName).isNull
        }
      case dt: DecimalType =>
        colType match {
          case `colVal` => col(colName) =!= ERR_CODE_NUM && col(colName).isNotNull
          case `colNull` => col(colName) === ERR_CODE_NUM || col(colName).isNull
        }
      case dt: DateType =>
        colType match {
          case `colVal` => col(colName) =!= ERR_CODE_DATE && col(colName).isNotNull
          case `colNull` => col(colName) === ERR_CODE_DATE || col(colName).isNull
        }
      case dt: TimestampType =>
        colType match {
          case `colVal` => col(colName) =!= ERR_CODE_DT && col(colName).isNotNull
          case `colNull` => col(colName) === ERR_CODE_DT || col(colName).isNull
        }
      case dt @  _ =>
        out(s"INFO: Unrecognized data type '$dt' of column $colName!")
        colType match {
          // in case of unsupported column's data type we suppose there is no emptry values in column
          case `colVal` => lit(true)
          case `colNull` => lit(false)
        }
    }
  }

  // schema for DataFrame with result of checks
  val checkTableSchema = StructType(
    StructField("unit", StringType, true) ::
      StructField("columnName", StringType, true) ::
      StructField("count", LongType, true) ::
      StructField("type", StringType, true) ::
      StructField("columnType", StringType, true) :: Nil
  )

  // return empty DataFRame of specified schema
  def getEmptyDf(spark: SparkSession, schema: StructType): DataFrame = {
    spark.createDataFrame(spark.sparkContext.emptyRDD[Row], schema)
  }

  // return DataFrame of specified table name
  def getTable(spark: SparkSession, tableName: String): DataFrame = {
    queryDf(spark, s"SELECT * FROM $tableName")
  }

  // convert List[Row] to DataFrame
  def createDfBySchema(spark: SparkSession, lst: List[Row], schema: StructType): DataFrame = {
    val tabRdd = spark.sparkContext.parallelize(lst)
    spark.createDataFrame(tabRdd, schema)
  }

  def checkDf(spark: SparkSession, tableName: String): DataFrame = {
    val df = getTable(spark, tableName)
    var dfOut = getEmptyDf(spark, checkTableSchema)

    out("----------------------------")
    out(s"INFO: Table $tableName")
    val tableUnits = df.select(unitName).distinct.collect.map(_(0))
    out("INFO: Units: " + tableUnits.mkString(", "))

    tableUnits.foreach { case (unit) =>
      out(s"INFO: Handling unit '$unit'")
      df.columns.foreach { case (colName) =>

        val dfSelect = colSelect(df, colName)
        val colDt = dfSelect.schema(colName).dataType

        // count columns' non-empty and empty values
        val cntVal = dfSelect.filter(col(unitName) === unit).filter(getFilter(col(colName), colDt, colName, colVal)).count
        val cntNull = dfSelect.filter(col(unitName) === unit).filter(getFilter(col(colName), colDt, colName, colNull)).count

        val tabList = List(
          Row(unit, colName, cntVal, colVal, colDt.toString),
          Row(unit, colName, cntNull, colNull, colDt.toString))

        val tabDf = createDfBySchema(spark, tabList, checkTableSchema)
        dfOut = dfOut.union(tabDf)
      }
    }
    dfOut
  }

  // handle 'check_empty' config object (i.e. run checking of empty values)
  def checkEmptyValues (spark: SparkSession, conf: Config): Unit = {
    out("INFO: Starting empty check...")
    val tablesList = conf.getConfigList("check_empty")
    val tables = new Array[DataFrame](tablesList.size())
    val iterator = tablesList.iterator()
    var i = 0
    while(iterator.hasNext){
      val entry = iterator.next()

      val tableName = entry.getString("tableName")
      val tempName = entry.getString("tempName")
      out("|- tableName: " + tableName)
      out("|- tempName:  " + tempName)

      tables(i) = checkDf(spark, tableName)
      tables(i).createOrReplaceTempView(tempName)
      i=i+1
    }
  }

  def main(args: Array[String]): Unit = {

    val spark = SparkSession
      .builder()
      .enableHiveSupport()
      //Required for overwriting ONLY the required partitioned folders, and not the entire root folder
      .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
      .getOrCreate()

    val argsMap = argsToOptionMap(args)

    var isArgsExist = true
    for (i <- argsList) {
      if (!argsMap.keySet.toSet.contains(i)) {
        isArgsExist = false
        break()
      }
    }

    if (isArgsExist) {
      val db_config_checks = argsMap.getOrElse("db_config_checks", null)  // config file with transformations for AML marts
      val launch_id = argsMap.getOrElse("launch_id", null)                // integration launch id

      out("INFO: Arguments: ")
      out("|- launch_id:  " + launch_id)

      // add lauch_id as system variable
      addSystemVar(SystemVar.LAUNCH_ID, launch_id)

      // get 'check' config file
      confChecks = loadFile(db_config_checks)

      try {
        out("INFO: Start reading Hive tables...")
        getHiveTables(spark, confChecks.getConfig("input"))
        out("INFO: Reading Hive tables succedded!")

        if(confChecks.hasPath("transform")){
          out("=============================================")
          out("INFO: Run 'transform' block")
          getTempTables(spark, confChecks)
        }

        if(confChecks.hasPath("check_empty")){
          out("=============================================")
          out("INFO: Run 'check_empty' block")
          checkEmptyValues(spark, confChecks)
        }

        out("=============================================")
        out("INFO: Start writing DataFrame to Hive...")
        writeToHive(spark, confChecks.getConfig("output"))
        out("INFO: writing to Hive succedded!")
      }
      catch {
        case ex: Throwable => out("ERROR: " + ex.getMessage)
      }
      finally {
        spark.stop()
      }
    }
  }

  def toTimestamp(dt: LocalDateTime): Timestamp = {
    Timestamp.valueOf(dt)
  }

  def toDate(dt: LocalDate): Date = {
    Date.valueOf(dt)
  }

  // generate target DataFrames to write to Hive
  def writeToHive(spark: SparkSession, conf: Config): Unit = {
    val hiveConf = conf.getConfigList("hive")
    val iterator = hiveConf.iterator()
    var i = 0
    while(iterator.hasNext){
      val entry = iterator.next()
      var df = makeDf(spark, entry.getConfig("sql"))
      printDfSchema(df)

      out("INFO: Start writing data to table...")
      saveToTable(df, entry.getConfig("save"))
      out("INFO: Writing data to table succeeded!")
    }
  }

  // save { partitionBy = [""], tablePath = ""}
  // save data to HDFS as partitioned DataFrame in parquet format
  def saveToTable(df: DataFrame, config: Config): Unit = {
    out("INFO: Start saving DataFrame to table...")
    var df_out = df
    val tablePath = config.getString("tablePath")

    if (config.hasPath("partitionBy")){
      val partitionLst: List[String] = config.getStringList("partitionBy").toList
      out("INFO: Partition by: " + partitionLst.mkString(" ,"))

      df_out = df.repartition(partitionLst.map(col(_)): _*)
      out("INFO: Writing partitioned DataFrame to table...")
      saveToHdfs(df_out, "overwrite", tablePath, partitionLst)
    }
    else{
      out("INFO: Writing [NOT] partitioned DataFrame to table...")
      saveToHdfs(df_out, "overwrite", tablePath)
    }
    out("INFO: Writing is OVER")
  }

  // write DataFrame to HDFS
  def saveToHdfs(df: DataFrame, mode: String, path: String): Unit = {
    out("INFO: Writing DataFrame [WITHOUT] partitions")
    out("|- mode:         " + mode)
    out("|- path:         " + path)
    df.write.mode(mode).format("parquet").save(path)
    out("INFO: Saving to HDFS succedded!")
  }

  // write DataFrame partitioned by 'partitionCol' to HDFS
  def saveToHdfs(df: DataFrame, mode: String, path: String, partitionCol: List[String]): Unit = {
    out("INFO: Writing DataFrame WITH partitions")
    out("|- partitionCol: " + partitionCol.mkString(", "))
    out("|- mode:         " + mode)
    out("|- path:         " + path)
    df.write.mode(mode).partitionBy(partitionCol: _*).format("parquet").save(path)
    out("INFO: Saving to HDFS succedded!")
  }

  // load JSONs from HDFS into DataFrames with tempName
  def getTempTables (spark: SparkSession, conf: Config): Unit = {
    val tablesList = conf.getConfigList("transform")
    val tables = new Array[DataFrame](tablesList.size())
    val iterator = tablesList.iterator()
    var i = 0
    while(iterator.hasNext){
      val entry = iterator.next()
      tables(i) = makeDf(spark, entry)
      i=i+1
    }
  }

  // load Parquet files from HDFS into DataFrames with tempName
  def getHiveTables (spark: SparkSession, conf: Config): Unit = {
    val hiveConf = conf.getConfigList("hive")
    val tables = new Array[DataFrame](hiveConf.size())
    val iterator = hiveConf.iterator()
    var i = 0
    while(iterator.hasNext){
      val entry = iterator.next()
      val tablePath = entry.getString("source.tablePath")
      val tempName = entry.getString("source.tempName")
      out("INFO: Start reading table: ")
      out("INFO: |- tablePath: " + tablePath)
      out("INFO: |- tempName: " + tempName)

      // reading Hive tables
      tables(i) = readParquet(spark, tablePath)
      tables(i).createOrReplaceTempView(tempName)

      // run sql query, window, show, count if specified
      tables(i) = makeDf(spark, entry.getConfig("sql"))
      tables(i).createOrReplaceTempView(tempName)
      i=i+1
    }
  }

  def readParquet(spark: SparkSession, path: String): DataFrame = {
    spark.read.format("parquet").load(path)
  }

  // return string with substituted values from system variables
  def replaceWithSysVar(str: String): String = {
    var strOut = str
    for((sys_name, sys_val) <- systemVarsMap){
      strOut = strOut.replaceAll(sys_name, sys_val)
    }
    strOut
  }
  // run SQL query from Config
  def getQueriedDf(spark: SparkSession, conf: Config): DataFrame = {
    val query = replaceWithSysVar(conf.getString("query"))
    out("INFO: Running query: \n" + query)
    queryDf(spark, query)
  }
  // run 'query' from config over DataFrame
  def queryDf(spark: SparkSession, query: String): DataFrame = {
    spark.sqlContext.sql(query)
  }

  def printDfSchema(df: DataFrame): Unit = {
    out("INFO: Print schema: \n")
    df.printSchema
  }

  // get windowed DataFrame
  def makeWindowDf(df: DataFrame, conf: Config): DataFrame = {
    val df_out = if (conf.hasPath("window.sortColumn") && conf.hasPath("window.columns")){
      out("INFO: Creating windowed DataFrame...")
      val sortColumn = conf.getString("window.sortColumn")
      val colList: List[String] = conf.getStringList("window.columns").toList
      out("|- window.sortColumn: " + sortColumn)
      out("|- window.columns:    " + colList.mkString(", "))
      makeWindow(df, colList, sortColumn)
    }
    else df
    df_out
  }

  // apply window to DataFrame
  def makeWindow(df: DataFrame, lstCol: List[String], sortCol: String): DataFrame = {
    val w = Window.partitionBy(lstCol.head, lstCol.tail: _*).orderBy(df.col(sortCol).desc)
    val dfTop = df.withColumn("rn", row_number.over(w)).where(col("rn") === 1).drop("rn")
    dfTop
  }

  // cache DataFrame if specifies in 'sql' Config
  def cacheDf(df: DataFrame, conf: Config): DataFrame ={
    if(conf.hasPath("cache") && conf.getBoolean("cache")){
      out("INFO: DataFrame is persisted!")
      cacheDf(df)
    }
    df
  }
  // cache DataFrame
  def cacheDf(df: DataFrame): DataFrame ={
    df.persist(StorageLevel.MEMORY_AND_DISK)
  }

  def makeDf(spark: SparkSession, config: Config): DataFrame = {
    out("INFO: Start making DataFrame...")
    // [required] run SQL query
    var df = getQueriedDf(spark, config)
    printDfSchema(df)
    // [optional] make windowed DataFrame
    df = makeWindowDf(df, config)

    if(config.hasPath("tempName")){
      out("INFO: |- tempName: " + config.getString("tempName"))
      df.createOrReplaceTempView(config.getString("tempName"))
    }

    // cache DataFrame if specifies in 'sql' Config
    df = cacheDf(df, config)
    // [optional] show specified number of items of DataFrame containing JSONs
    showDf(df, config)
    // [optional] count DataFrame's rows if specified
    countDf(df, config)
    df
  }

  // print DataFrame
  def showDf(df: DataFrame, conf: Config): Unit = {
    if(conf.hasPath("show") && conf.hasPath("show.limit")){
      out("INFO: Show " + conf.getInt("show.limit") + " rows of DF: \n")
      df.limit(conf.getInt("show.limit")).show(false)
    }
  }

  // count DataFrame rows
  def countDf(df: DataFrame, conf: Config): Unit = {
    if(conf.hasPath("count") && conf.getBoolean("count")){
      out("INFO: Number of rows in DataFrame: " + df.count())
    }
  }

  def argsToOptionMap(args:Array[String]):Map[String,String]= {
    def nextOption(argList:List[String], map:Map[String, String]) : Map[String, String] = {
      val pattern       = "--(\\w+)".r // Selects Arg from --Arg
      val patternSwitch = "-(\\w+)".r  // Selects Arg from -Arg
      argList match {
        case Nil => map
        case pattern(opt)       :: value  :: tail => nextOption( tail, map ++ Map(opt -> value) )
        case patternSwitch(opt) :: tail => nextOption( tail, map ++ Map(opt -> null) )
        case string             :: Nil  => map ++ Map(string -> null)
        case option             :: tail => {
          out("Unknown option:" + option)
          sys.exit(1)
        }
      }
    }
    nextOption(args.toList,Map())
  }

  // parse file to Config
  def parseConfig(file: File): Config = {
    val envConfig = ConfigFactory.parseFile(file)
    println("INFO: Configuration was loaded from file: " + file.getPath)
    envConfig
  }

  def loadFile(fname: String): Config = {
    val set_file = new File(fname)
    if (set_file.exists) {
      return parseConfig(set_file)
    }
    throw new Exception("ERROR: Files does not exist: " + fname)
  }

  def getNow(): String = {
    java.time.LocalDateTime.now.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"))
  }

  def out(msg: String): Unit = {
    println(getNow() + "\t" + msg)
  }

  // system variables names
  object SystemVar extends Enumeration {
    type SystemVar = Value
    val LAUNCH_ID = "SYS_LAUNCH_ID"
  }

}
