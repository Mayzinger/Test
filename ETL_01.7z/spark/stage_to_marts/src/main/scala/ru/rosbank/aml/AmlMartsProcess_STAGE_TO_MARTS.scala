package ru.rosbank.aml

import com.typesafe.config.{Config, ConfigFactory}
import java.io.File
import java.sql.{Date, Timestamp}
import java.time.format.DateTimeFormatter
import java.time.{LocalDate, LocalDateTime, ZoneId}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.expressions.Window
import scala.collection.mutable.{ListBuffer, Map}
import scala.util.control.Breaks.break
import scala.util.{Try, Success, Failure}

import collection.JavaConversions._

object AmlMartsProcess_STAGE_TO_MARTS {

  var confCalc : Config = _
  var confTables : Config = _
  var confSrcTables : Config = _
  // environment config
  var envConf: Config = _
  //config for logging
  var logConf: Config = _

  // oozie workflow id
  var launch_id: String = _

  var MART_NAME = ""
  var in_unit: String = _
  val UNIT_DEFAULT = "NO_UNIT"

  val EMPTY_ERR_MESSAGE = "NO_ERROR_MESSAGE"

  val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
  val datetimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

  val argsList = List("db_config_calc", "db_config_tables", "db_config_src", "db_config_env", "launch_id")

  // Map with system variables
  var systemVarsMap = Map.empty[String, String]

  // default values for errors
  val ERR_CODE_DEFAULT : String = "-1"
  val ERR_CODE_DATE_DEFAULT : Date = toDate(LocalDate.parse("1900-01-01", dateFormatter))
  val ERR_CODE_DT_DEFAULT : Timestamp = toTimestamp(LocalDateTime.parse("1900-01-01 00:00:00", datetimeFormatter))

  // parse String to LocalDateTime
  def parseDate(str: String, frmt: DateTimeFormatter): LocalDateTime = {
    LocalDateTime.parse(str, frmt)
  }

  def toTimestamp(dt: LocalDateTime): Timestamp = {
    Timestamp.valueOf(dt)
  }

  def toDate(dt: LocalDate): Date = {
    Date.valueOf(dt)
  }

  // add system variable to Map
  def addSystemVar(sys_name: String, sys_val: String): Unit = {
    systemVarsMap += (sys_name -> sys_val)
    out(s"INFO: Added system variable: $sys_name = $sys_val")
  }

  def getSparkSession(): SparkSession = {
    val spark = SparkSession
      .builder()
      .enableHiveSupport()
      //required for overwriting ONLY the required partitioned folders, and not the entire root folder
      .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
      //merge schemas of all parquet files instead of picking a random one
      .config("spark.sql.parquet.mergeSchema", "true")
      .getOrCreate()
    import spark.implicits._
    spark
  }

  // set AML mart name
  def setMartName(conf: Config): String = {
    MART_NAME = if(conf.hasPath("tableName")) conf.getString("tableName") else "MART_NAME_NOT_SET"
    MART_NAME
  }

  // get Spark application name
  def getAppName(spark: SparkSession): String = {
    spark.sqlContext.getAllConfs.get("spark.app.name") match {
      case Some(appName) => appName
      case None => "APLICATION_NAME_NOT_SET"
    }
  }

  def main(args: Array[String]): Unit = {

    val spark = getSparkSession()
    val argsMap = argsToOptionMap(args)

    var isArgsExist = true
    for (i <- argsList) {
      if (!argsMap.keySet.toSet.contains(i)) {
        isArgsExist = false
        break()
      }
    }

    if (isArgsExist) {
      val db_config_calc = argsMap.getOrElse("db_config_calc", null)     // config file with transformations for AML marts
      val db_config_tables = argsMap.getOrElse("db_config_tables", null) // config file with AML marts DDL
      val db_config_src = argsMap.getOrElse("db_config_src", null)       // config with source tables used for AML marts calculation
      val db_config_env = argsMap.getOrElse("db_config_env", null) // (aml_env.conf) environment configuration (logging table conf, ...)
      in_unit = argsMap.getOrElse("unit", UNIT_DEFAULT)
      launch_id = argsMap.getOrElse("launch_id", null)             // integration launch id

      out("INFO: Arguments: ")
      out("|- db_config_calc:    " + db_config_calc)
      out("|- db_config_tables:  " + db_config_tables)
      out("|- db_config_env:     " + db_config_env)
      if(in_unit != UNIT_DEFAULT){
        out("|- unit:            " + in_unit)
      }
      else {
        out("|- unit: No filter source data by unit set up")
      }

      //add system variables to Map
      addSystemVar(SysVar.SYS_UNIT, in_unit)
      addSystemVar(SysVar.SYS_APP_NAME, getAppName(spark))

      confCalc = loadFile(db_config_calc)
      confTables = loadFile(db_config_tables)
      confSrcTables = loadFile(db_config_src)
      envConf = loadFile(db_config_env)      // get environment config

      logConf = envConf.getConfig("logging") // logging conf

      out("INFO: AML mart name: " + setMartName(confCalc))

      try {
        out("INFO: Start reading Hive tables...")
        getHiveTables(spark, confCalc.getConfig("input"))
        out("INFO: Reading Hive tables succeeded!")

        // if transformation block exists
        if(confCalc.hasPath("transform")){
          out("=============================================")
          out("INFO: Run 'transform' block")
          getTempTables(spark, confCalc)
        }

        out("=============================================")
        out("INFO: Start writing DataFrame to Hive...")
        writeToHive(spark, confCalc.getConfig("output"))

        logSuccessEvent(spark, MART_NAME, EventType.WRITE_TO_HIVE)
        out("INFO: writing to Hive succeeded!")
      }
      catch {
        case hiveex: HiveReadingException =>
          out("ERROR: Exception occurred while reading source Hive table")
          out("ERROR: Exception: " + hiveex.getMessage)
          logErrorEvent(spark, MART_NAME, EventType.READ_HIVE, hiveex.getMessage)
        case hivetr: HiveTransformException =>
          out("ERROR: Exception occurred in 'transform' section")
          out("ERROR: Exception: " + hivetr.getMessage)
          logErrorEvent(spark, MART_NAME, EventType.RUN_TRANSFORM, hivetr.getMessage)
        case hivewriteex: HiveWritingException =>
          out("ERROR: Exception occurred in 'output.hive' section")
          out("ERROR: Exception: " + hivewriteex.getMessage)
          logErrorEvent(spark, MART_NAME, EventType.WRITE_TO_HIVE, hivewriteex.getMessage)
        case ex: Exception =>
          out("ERROR: System exception: " + ex.getMessage)
          logErrorEvent(spark, MART_NAME, EventType.SYS_ERROR, getErrorMessage(ex.getMessage))
      }
      finally {
        spark.stop()
      }
    }
    else {
      out("*********************************************")
      out("ERROR: Some required arguments are missed!")
      out("*********************************************")
    }
    spark.stop()
  }

  case class LogTable(launch_id: String = null,
                      unit: String = null,
                      table_schema: String = null,
                      table_name: String = null,
                      source_system: String = null,
                      status: String = null,
                      load_date_from: Timestamp = null,
                      load_date_to: Timestamp = null,
                      error_message: String = null,
                      json_file: String = null,
                      json_file_corrupted_rec: String = null,
                      day_close: Date = null,
                      load_timestamp: Timestamp = null,
                      event_type: String = null,
                      app_name: String = null
                     )

  // get table meta Config
  def getTableMeta (tableName: String): Try[Config] = {
    Try(confTables.getConfig(tableName))
  }

  // check is column is nullable or not based on config
  def checkColIsRequired(tableConf: Config, colName: String): Boolean = {
    var res = false
    if(tableConf.hasPath(colName)){
      val colConf = tableConf.getConfig(colName)
      if(colConf.hasPath("nullable") && !colConf.getBoolean("nullable")){
        res = true
      }
    }
    res
  }

  // get error code for column for BigDecimal data type
  def getNumErrCode(isColRequied: Boolean): java.math.BigDecimal = {
    isColRequied match {
      case false => null
      case _ => new java.math.BigDecimal(ERR_CODE_DEFAULT)
    }
  }

  // get error code for column for String data type
  def getStrErrCode(isColRequied: Boolean): String = {
    isColRequied match {
      case false => null
      case _ => ERR_CODE_DEFAULT
    }
  }

  // get error code for column for Date data type
  def getDateErrCode(isColRequied: Boolean): Date = {
    isColRequied match {
      case false => null
      case _ => ERR_CODE_DATE_DEFAULT
    }
  }

  // get error code for column for Timestamp data type
  def getDateTimeErrCode(isColRequied: Boolean): Timestamp = {
    isColRequied match {
      case false => null
      case _ => ERR_CODE_DT_DEFAULT
    }
  }

  // function for UDF for filling empty values for Date data type
  def fillDateNulls (colVal: Date, isColRequied: Boolean): Date = {
    colVal match {
      case null => getDateErrCode(isColRequied)  // value is empty, is required
      case _ => colVal
    }
  }

  // function for UDF for filling empty values for string data type
  def fillStrNulls (colVal: String, isColRequied: Boolean): String = {
    colVal match {
      case null => getStrErrCode(isColRequied) // value is null
      case _ =>
        colVal.trim.isEmpty match {
          case true => getStrErrCode(isColRequied) // value [NOT] null, empty, is required
          case false => colVal
        }
    }
  }

  def fillNumNulls (colVal: java.math.BigDecimal, isColRequied: Boolean): java.math.BigDecimal = {
    colVal match {
      case null => getNumErrCode(isColRequied)  // value is empty, is required
      case _ => colVal
    }
  }

  def fillDateTimeNulls (colVal: Timestamp, isColRequied: Boolean): Timestamp = {
    colVal match {
      case null => getDateTimeErrCode(isColRequied)  // value is empty, is required
      case _ => colVal
    }
  }

  // UDF for filling empty values for String data type
  def fillStrNullsUDF = udf((colVal: String, isColRequied: Boolean) =>
    fillStrNulls(colVal, isColRequied)
  )

  // UDF for filling empty values for BigDecimal data type
  def fillNumNullsUDF = udf((colVal: java.math.BigDecimal, isColRequied: Boolean) =>
    fillNumNulls(colVal, isColRequied)
  )

  // UDF for filling empty values for Date data type
  def fillDateNullsUDF = udf((colVal: Date, isColRequied: Boolean) =>
    fillDateNulls(colVal, isColRequied)
  )

  // UDF for filling empty values for Timestamp data type
  def fillDateTimeNullsUDF = udf((colVal: Timestamp, isColRequied: Boolean) =>
    fillDateTimeNulls(colVal, isColRequied)
  )

  // update DataFrame filling empty values
  def convertDfNulls (df: DataFrame, tableConf: Config = null): DataFrame = {
    out("==============================================")
    out("INFO: Handling empty values...'")
    out("INFO: DataFrame's columns: ")
    df.columns.foreach{ c => out("INFO: |- " + c)}

    df.columns.foldLeft(df){ case (accDf, colName) =>
      out("-----------------------------------------------")
      out("---------------[Handling column]---------------")
      out("INFO: |- column:             " + colName)
      out("INFO: |- data type:          " + df.schema(colName).dataType.toString)

      val isColRequied = Try(checkColIsRequired(tableConf, colName)) match {
        case Success(isreq) => isreq
        case Failure(ex) => false
      }
      out("INFO: |- is column required: " + isColRequied)

      df.schema(colName).dataType match {
        // we handle empty values only for StringType, DecimalType types, DateType, TimestampType
        case dt: StringType => accDf.withColumn(colName, fillStrNullsUDF(col(colName), lit(isColRequied)))
        case dt: DecimalType => accDf.withColumn(colName, fillNumNullsUDF(col(colName), lit(isColRequied)))
        case dt: DateType => accDf.withColumn(colName, fillDateNullsUDF(col(colName), lit(isColRequied)))
        case dt: TimestampType => accDf.withColumn(colName, fillDateTimeNullsUDF(col(colName), lit(isColRequied)))
        case _ => accDf.withColumn(colName, col(colName))
      }
    }
  }

  // get table's columns' information based on config
  def convertNull(df: DataFrame, tableName: String): DataFrame = {
    var dfOut = df
    val tableMeta = getTableMeta(tableName) match {
      case Success(tblConf) =>
        out("INFO: 2. Table meta loading from Config")
        dfOut = convertDfNulls(dfOut, tblConf)
      case Failure(ex) =>
        out("Print ex: " + ex.getMessage)
        out("INFO: 2. Table meta is not specified!")
        dfOut = convertDfNulls(dfOut)
    }
    dfOut
  }

  // return updated DataFrame based on incremental and historical data
  def getUpdatedDf(spark: SparkSession, tableName: String, conf: Config): DataFrame = {
    // get SNP_INCR (last transformation block) as DataFRame
    val snpIncrSrcName = conf.getString("updatePartition.source")
    val snpIncrTrgName = conf.getString("updatePartition.target")

    out("INFO: |- source: " + snpIncrSrcName)
    out("INFO: |- target: " + snpIncrTrgName)

    var snpIncrDf = getDfByName(spark, snpIncrSrcName)
    cacheDf(snpIncrDf)
    out("INFO: Count incremental df: " +  snpIncrDf.count())
    snpIncrDf.createOrReplaceTempView(snpIncrSrcName)

    // convert empty values for incremental part
    snpIncrDf = convertNull(snpIncrDf, tableName)
    snpIncrDf.createOrReplaceTempView(snpIncrSrcName)
    out("INFO: Schema of incrementDf (converted null): ")
    printDfSchema(snpIncrDf)

    // create unioned DataFrame (incremental and historical parts)
    out("INFO: Start to union incremental and historical data...")
    unionDf(spark, conf)

    // run final query to generate DataFrame to be saved
    snpIncrDf = makeDf(spark, conf.getConfig("sql"))
    snpIncrDf
  }

  // generate target DataFrames to write to Hive
  def writeToHive(spark: SparkSession, conf: Config): Unit = {
    val hiveConf = conf.getConfigList("hive")
    val iterator = hiveConf.iterator()
    var i = 0
    while(iterator.hasNext){
      val entry = iterator.next()
      try {
        val tableName = entry.getString("tableName")

        if(entry.hasPath("updatePartition")){
          out("INFO: 'updatePartition' block is configured")
          val updatedDf = getUpdatedDf(spark, tableName, entry)

          out("INFO: Start writing data to table...")
          saveToTable(updatedDf, entry.getConfig("save"), SaveMode.Overwrite)
        }
        else {
          out("INFO: 'updatePartition' block is [NOT] configured!")
          var df = makeDf(spark, entry.getConfig("sql"))
          df = convertNull(df, tableName)

          out("INFO: Start writing data to table...")
          saveToTable(df, entry.getConfig("save"), SaveMode.Overwrite)
        }
        out("INFO: Writing data to table succeeded!")
      }
      catch {
        case ex: Exception => throw new HiveWritingException("Error occurred in output.hive section: " + ex.getMessage)
      }
    }
  }

  def readHdfs (spark: SparkSession, path: String): Try[DataFrame] = {
    out("INFO: Reading data from path: " + path)
    Try(readParquet(spark, path))
  }

  // return DataFrame by view name
  def getDfByName(spark: SparkSession, tempName: String): DataFrame = {
    spark.sql("SELECT * FROM " + tempName)
  }

  // filter DataFrame by unit
  def filterByUnit(df: DataFrame): DataFrame = {
    df.filter(col("unit") === systemVarsMap(SysVar.SYS_UNIT))
  }

  //reorder DataFrame's columns according to another DataFrame
  def reorderCols(dfToOrder: DataFrame, dfByOrder: DataFrame): DataFrame = {
    val colsByOrder = dfByOrder.columns.toList
    dfToOrder.select(colsByOrder.head, colsByOrder.tail: _*)
  }

  // log successful event
  def logSuccessEvent(spark: SparkSession, tableName: String, eventType: String): Unit = {
    out("INFO: Logging success event...")
    out("INFO: |- tableName: " + tableName)
    logEvent(spark, tableName, EventStatus.SUCCESS, eventType)
  }

  // log error event
  def logErrorEvent(spark: SparkSession, tableName: String, eventType: String, errorMessage: String): Unit = {
    out("INFO: Logging error event...")
    out("INFO: |- tableName: " + tableName)
    out("INFO: |- error_message: " + errorMessage)
    logEvent(spark, tableName, EventStatus.ERROR, eventType, errorMessage)
  }

  def isEmpty(str: String): Boolean = {
    var res = true
    if(str != null){
      if(!str.trim.isEmpty){
        res = false
      }
    }
    res
  }

  // format error message
  def getErrorMessage(mess: String): String = {
    if(isEmpty(mess)){
      EMPTY_ERR_MESSAGE
    }
    else {
      mess.slice(0, 149)
    }
  }

  /** Log event (error, warning, success) during integration
    *
    * @param spark SparkSession
    * @param tableName table name by which we get meta information about source data (table path, source system, etc.)    *
    * @param eventStatus event status (EventStatus enum)
    * @param eventType event type (EventType enum)
    * @param errorMessage event message (error, warning, successful)
    */
  def logEvent(spark: SparkSession, tableName: String, eventStatus: String, eventType: String, errorMessage: String = null): Unit = {
    out("INFO: Writing event to log table...")
    out("INFO: |- tableName: " + tableName)
    val errMessage = getErrorMessage(errorMessage)
    out("INFO: |- error_message: " + errMessage)

    val eventDf = getEventMessage(spark, tableName, errMessage, eventStatus, eventType)
    writeToLog(eventDf)
    out("INFO: Writing succeeded!")
  }

  // write prepaired DataFrame to Log table
  def writeToLog(df: DataFrame): Unit = {
    out("INFO: Start writing to log table...")
    saveToTable(df, logConf, SaveMode.Append)
  }

  /** Generate DataFrame with event information to be written to log table
    *
    * @param spark SparkSession
    * @param error_message event message (error, warning, successful)
    * @param eventStatus event status (EventStatus enum)
    * @param eventType event type (EventType enum)
    * @return DataFrame with event information
    */
  def getEventMessage(spark: SparkSession, tableName: String, error_message: String, eventStatus: String, eventType: String): DataFrame = {
    val errMessageLst = List(
      LogTable(
        // get from spark-submit
        app_name = systemVarsMap(SysVar.SYS_APP_NAME),
        launch_id = launch_id,
        // get from Config
        table_name = tableName,
        unit = systemVarsMap(SysVar.SYS_UNIT),
        // constants
        event_type = eventType,
        status = eventStatus,
        error_message = error_message,
        load_timestamp = toTimestamp(getCurrentTimestamp())
      )
    )
    spark.createDataFrame(errMessageLst)
  }

  // return DataFrame (new increment from stage and hist)
  def unionDf(spark: SparkSession, conf: Config): Unit = {
    val updConf = conf.getConfig("updatePartition")
    val updSource = updConf.getString("source")
    val updTarget = updConf.getString("target")
    val updParKey = updConf.getString("partitionToUpdate")

    out("INFO: |- unit:              " + systemVarsMap(SysVar.SYS_UNIT))
    out("INFO: |- source:            " + updSource)
    out("INFO: |- target:            " + updTarget)
    out("INFO: |- partitionToUpdate: " + updParKey)

    val martTablePath = conf.getString("save.tablePath")
    out("INFO: AML mart table path:   " + martTablePath)

    // try to read AML mart
    var martTableDf: Try[DataFrame] = readHdfs(spark, martTablePath)

    martTableDf match {
      // data exists in AML mart
      case Success(martTbl) =>
        out("INFO: Getting AML mart increment...")
        var saIncr = getDfByName(spark, updSource)

        // get list of partitions to be updated in Hist
        val partitionToUpd = broadcast(cacheDf(saIncr.select(updParKey).filter(col(updParKey).isNotNull).distinct))
        partitionToUpd.createOrReplaceTempView("partitionToUpd")

        out("INFO: Partitions comming from Stage incremental data: ")
        partitionToUpd.show(false)

        // filter Hist by unit (or get all data (unit = 'NO_UNIT'))
        out("INFO: Filtering AML mart by unit: " + systemVarsMap(SysVar.SYS_UNIT))
        var filteredMart = filterByUnit(martTbl)
        filteredMart.createOrReplaceTempView("filteredMart")

        out("INFO: Hist partitions to be updated: ")
        val martPartitionsToUpdList = spark.sql(s"SELECT $updParKey FROM partitionToUpd sa WHERE $updParKey IN (SELECT $updParKey FROM filteredMart)")
        martPartitionsToUpdList.show(false)

        out("INFO: Hist partitions to be inserted: ")
        val martPartitionsToInsertList = spark.sql(s"SELECT $updParKey FROM partitionToUpd sa WHERE $updParKey NOT IN (SELECT $updParKey FROM filteredMart)")
        martPartitionsToInsertList.show(false)

        // get AML mart data filtered by new partitions and unit from increment
        val martToUpdate = spark.sql(s"SELECT * FROM filteredMart WHERE $updParKey IN (SELECT $updParKey FROM partitionToUpd)")

        // reorder Stage increment Df's columns according to Marts Df's columns
        saIncr = reorderCols(saIncr, martToUpdate)

        // union stage and hist data
        val stageAndHistDf = saIncr.union(martToUpdate)
        stageAndHistDf.createOrReplaceTempView(updTarget)

      case Failure(ex) =>
        out("WARN: No data exists in AML mart")
        out("WARN: Print ex: " + ex.getMessage)
        // no data exists in Hist, get data from Stage
        out("INFO: Reading data from Stage...")
        val saIncr = getDfByName(spark, updSource)
        saIncr.createOrReplaceTempView(updTarget)
    }
  }


  // save { partitionBy = [""], tablePath = ""}
  // save data to HDFS as partitioned DataFrame in parquet format
  def saveToTable(df: DataFrame, config: Config, saveMode: SaveMode): Unit = {
    out("INFO: Start saving DataFrame to table...")
    val tablePath = config.getString("tablePath")

    // get partitioned or not dataframe and list of partitioned keys
    val (df_out, partitionLst) = partitionDf(df, config)

    if(partitionLst.isEmpty){
      out("INFO: Writing [NOT] partitioned DataFrame to table...")
      saveToHdfs(df_out, saveMode, tablePath)
    }
    else {
      out("INFO: Writing partitioned DataFrame to table...")
      saveToHdfs(df_out, saveMode, tablePath, partitionLst)
    }
    out("INFO: Writing is OVER")
  }

  // return partitioned DataFrame based on Config
  def partitionDf(df: DataFrame, config: Config): (DataFrame, List[String]) = {
    var df_out = df
    var partitionLst = List.empty[String]

    if (config.hasPath("partitionBy")){
      partitionLst = config.getStringList("partitionBy").toList
      out("INFO: Partition by: " + partitionLst.mkString(", "))

      df_out = df_out.repartition(partitionLst.map(col(_)): _*)
    }
    printDfSchema(df_out)
    (df_out, partitionLst)
  }

  // write DataFrame partitioned by 'partitionCol' to HDFS
  def saveToHdfs(df: DataFrame, saveMode: SaveMode, path: String, partitionCol: List[String]): Unit = {
    out("INFO: Writing DataFrame WITH partitions")
    out("INFO: |- partitionCol: " + partitionCol.mkString(", "))
    out("INFO: |- mode:         " + saveMode.toString)
    out("INFO: |- path:         " + path)
    out("INFO: |- Partitions number: " + df.rdd.getNumPartitions)
    df.write.mode(saveMode).partitionBy(partitionCol: _*).format("parquet").save(path)
    out("INFO: Saving to HDFS succedded!")
  }

  // write DataFrame to HDFS
  def saveToHdfs(df: DataFrame, saveMode: SaveMode, path: String): Unit = {
    out("INFO: Writing DataFrame [WITHOUT] partitions")
    out("INFO: |- mode:         " + saveMode.toString)
    out("INFO: |- path:         " + path)
    out("INFO: |- Partitions number: " + df.rdd.getNumPartitions)
    df.write.mode(saveMode).format("parquet").save(path)
    out("INFO: Saving to HDFS succedded!")
  }

  // load JSONs from HDFS into DataFrames with tempName
  def getTempTables (spark: SparkSession, conf: Config): Unit = {
      val tablesList = conf.getConfigList("transform")
      val tables = new Array[DataFrame](tablesList.size())
      val iterator = tablesList.iterator()
      var i = 0
      while(iterator.hasNext){
        val entry = iterator.next()
        try {
          tables(i) = makeDf(spark, entry)
          i = i + 1
        }
        catch {
          case ex: Exception => throw new HiveTransformException("Hive transformation error: " + ex.getMessage)
        }
      }
  }

  // run 'query' from config over DataFrame
  def queryDf(spark: SparkSession, query: String): DataFrame = {
    spark.sqlContext.sql(query)
  }

  //return source table filtered by unit based on src_tables.conf
  def filterByUnit(dfIn: DataFrame, tableName: String): DataFrame = {
    var df_out = dfIn
    //if table in specified in src_tables.conf
    if(confSrcTables.hasPath("tables." + tableName)){
      val tableConf = confSrcTables.getConfig("tables." + tableName)
      //if --unit is specified in spark submit
      if(in_unit != UNIT_DEFAULT){
        //if table in src_tables.conf is replicated by unit
        if(tableConf.hasPath("replicatedByUnit") && tableConf.getBoolean("replicatedByUnit")){
          out(s"INFO: Source table '$tableName' is replicated by unit")
          out(s"INFO: Filter data for table '$tableName' with unit = '$in_unit'")
          df_out = df_out.filter(col("unit") === in_unit)
        }
      }
    }
    else {
      throw new Exception("ERROR: Source table configuration is not found in src_tables.conf")
    }
    df_out
  }

  // load Parquet files from HDFS into DataFrames with tempName
  def getHiveTables (spark: SparkSession, conf: Config): Unit = {
    try {
      val hiveTableConf: List[Config] = conf.getConfigList("hive").toList
      val tables = new Array[DataFrame](hiveTableConf.size())
      val iterator = hiveTableConf.iterator()
      var i = 0
      while(iterator.hasNext){
        val entry = iterator.next()

        val tableName = entry.getString("source.tableName")
        val tablePath = entry.getString("source.tablePath")
        val tempName = entry.getString("source.tempName")
        out("INFO: Start reading table: ")
        out("INFO: |- tableName: " + tableName)
        out("INFO: |- tablePath: " + tablePath)
        out("INFO: |- tempName: " + tempName)

        // reading Hive tables
        tables(i) = readParquet(spark, tablePath)
        tables(i).createOrReplaceTempView(tempName)

        // filter source table by unit if it's specified in Config
        tables(i) = filterByUnit(tables(i), tableName)
        tables(i).createOrReplaceTempView(tempName)

        // run sql query, window, show, count if specified
        tables(i) = makeDf(spark, entry.getConfig("sql"))
        tables(i).createOrReplaceTempView(tempName)
        i=i+1
      }
    }
    catch {
      case ex: Exception => throw new HiveReadingException("Reading Hive tables. Exception: " + ex.getMessage)
    }
  }

  def readParquet(spark: SparkSession, path: String): DataFrame = {
    spark.read.format("parquet").load(path)
  }

  def makeDf(spark: SparkSession, config: Config): DataFrame = {
    out("INFO: Start making DataFrame...")
    // [required] run SQL query
    var df = getQueriedDf(spark, config)
    printDfSchema(df)
    // [optional] make windowed DataFrame
    df = makeWindowDf(df, config)

    if(config.hasPath("tempName")){
      out("INFO: |- tempName: " + config.getString("tempName"))
      df.createOrReplaceTempView(config.getString("tempName"))
    }

    // cache DataFrame if specifies in 'sql' Config
    df = cacheDf(df, config)
    // [optional] show specified number of items of DataFrame containing JSONs
    showDf(df, config)
    // [optional] count DataFrame's rows if specified
    countDf(df, config)
    df
  }

  // return string with substituted values from system variables
  def replaceWithSysVar(str: String): String = {
    var strOut = str
    for((sys_name, sys_val) <- systemVarsMap){
      strOut = strOut.replaceAll(sys_name, sys_val)
    }
    strOut
  }

  // run SQL query from Config
  def getQueriedDf(spark: SparkSession, conf: Config): DataFrame = {
    val query = replaceWithSysVar(conf.getString("query"))
    out("INFO: Running query: \n" + query)
    queryDf(spark, query)
  }


  def printDfSchema(df: DataFrame): Unit = {
    out("INFO: Print schema: \n")
    df.printSchema
  }

  // get windowed DataFrame
  def makeWindowDf(df: DataFrame, conf: Config): DataFrame = {
    val df_out = if (conf.hasPath("window.sortColumn") && conf.hasPath("window.columns")){
      out("INFO: Creating windowed DataFrame...")
      val sortColumn = conf.getString("window.sortColumn")
      val colList: List[String] = conf.getStringList("window.columns").toList
      out("|- window.sortColumn: " + sortColumn)
      out("|- window.columns:    " + colList.mkString(", "))
      makeWindow(df, colList, sortColumn)
    }
    else df
    df_out
  }

  // cache DataFrame if specifies in 'sql' Config
  def cacheDf(df: DataFrame, conf: Config): DataFrame ={
    if(conf.hasPath("cache") && conf.getBoolean("cache")){
      out("INFO: DataFrame is persisted!")
      cacheDf(df)
    }
    df
  }
  // cache DataFrame
  def cacheDf(df: DataFrame): DataFrame ={
    df.persist(StorageLevel.MEMORY_AND_DISK)
  }

  // apply window to DataFrame
  def makeWindow(df: DataFrame, lstCol: List[String], sortCol: String): DataFrame = {
    val w = Window.partitionBy(lstCol.head, lstCol.tail: _*).orderBy(df.col(sortCol).desc)
    val dfTop = df.withColumn("rn", row_number.over(w)).where(col("rn") === 1).drop("rn")
    dfTop
  }

  // print DataFrame
  def showDf(df: DataFrame, conf: Config): Unit = {
    if(conf.hasPath("show") && conf.hasPath("show.limit")){
      out("INFO: Show " + conf.getInt("show.limit") + " rows of DF: \n")
      df.limit(conf.getInt("show.limit")).show(false)
    }
  }

  // count DataFrame rows
  def countDf(df: DataFrame, conf: Config): Unit = {
    if(conf.hasPath("count") && conf.getBoolean("count")){
      out("INFO: Number of rows in DataFrame: " + df.count())
    }
  }

  def getCurrentTimestamp(): LocalDateTime = {
    LocalDateTime.now()
  }

  def argsToOptionMap(args:Array[String]):Map[String,String]= {
    def nextOption(argList:List[String], map:Map[String, String]) : Map[String, String] = {
      val pattern       = "--(\\w+)".r // Selects Arg from --Arg
      val patternSwitch = "-(\\w+)".r  // Selects Arg from -Arg
      argList match {
        case Nil => map
        case pattern(opt)       :: value  :: tail => nextOption( tail, map ++ Map(opt -> value) )
        case patternSwitch(opt) :: tail => nextOption( tail, map ++ Map(opt -> null) )
        case string             :: Nil  => map ++ Map(string -> null)
        case option             :: tail => {
          out("Unknown option:" + option)
          sys.exit(1)
        }
      }
    }
    nextOption(args.toList,Map())
  }

  // parse file to Config
  def parseConfig(file: File): Config = {
    val envConfig = ConfigFactory.parseFile(file)
    println("INFO: Configuration was loaded from file: " + file.getPath)
    envConfig
  }

  def loadFile(fname: String): Config = {
    val set_file = new File(fname)
    if (set_file.exists) {
      return parseConfig(set_file)
    }
    throw new Exception("ERROR: Files does not exist: " + fname)
  }

  final case class HiveReadingException(private val message: String = "", private val cause: Throwable = None.orNull) extends Exception (message, cause)
  final case class HiveTransformException(private val message: String = "", private val cause: Throwable = None.orNull) extends Exception (message, cause)
  final case class HiveWritingException(private val message: String = "", private val cause: Throwable = None.orNull) extends Exception (message, cause)

  def getNow(): String = {
    java.time.LocalDateTime.now.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"))
  }

  def out(msg: String): Unit = {
    println(getNow() + "\t" + msg)
  }
  // event statuses for logging table
  object EventStatus extends Enumeration {
    type EventStatus = Value
    val SUCCESS = "success"
    val ERROR = "error"
    val WARN = "warn"
  }

  // event types for logging table
  object EventType extends Enumeration {
    type EventType = Value
    val READ_HIVE = "reading_hive_tables"
    val RUN_TRANSFORM = "transforming_data"
    val WRITE_TO_HIVE = "writing_to_hive"
    val SYS_ERROR = "system_error"
  }

  // system variables
  object SysVar extends Enumeration {
    type SysVar = Value
    val SYS_UNIT = "SYS_UNIT"             // unit specified in spark-submit
    val SYS_APP_NAME = "SYS_APP_NAME"     // spark application name
  }

}