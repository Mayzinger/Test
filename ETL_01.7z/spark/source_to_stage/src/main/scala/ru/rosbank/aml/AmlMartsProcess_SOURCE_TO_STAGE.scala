package ru.rosbank.aml

import com.typesafe.config.{Config, ConfigFactory}
import java.io.File
import java.sql.{Date, Timestamp}
import java.time.format.DateTimeFormatter
import java.time.{LocalDate, LocalDateTime, ZoneId}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.storage.StorageLevel
import scala.collection.mutable.{ListBuffer, Map}
import scala.util.control.Breaks.break
import scala.util.{Try, Success, Failure}

import collection.JavaConversions._

object AmlMartsProcess_SOURCE_TO_STAGE {

  var fs : FileSystem = _

  // based Config
  var conf : Config = _
  // environment config
  var envConf: Config = _
  //source tables config
  var srcTabsConf: Config = _
  //config for logging
  var logConf: Config = _

  var dateFrom : LocalDateTime = _
  var dateTo : LocalDateTime = _
  // oozie workflow id
  var launch_id: String = _

  // start and stop datetime of Spark job
  var startImport: LocalDateTime = _
  var stopImport: LocalDateTime = _

  // unit variable
  var in_unit: String = _
  val UNIT_DEFAULT = "NO_UNIT"
  val EMPTY_ERR_MESSAGE = "NO_ERROR_MESSAGE"
  val TABLE_NAME_NOT_SET = "TABLE_NAME_NOT_SET"
  val NO_INFO = "NO_INFO"

  val argsList =
    List("launch_id", "date_from", "date_to", "db_config", "db_config_env", "db_config_src")
  // Map with system variables
  var systemVarsMap: Map[String, String] = Map()
  // Map with meta information about all source tables
  var srcTablesMeta: Map[String, Map [String, String]] = Map()

  // table name is currently handled (import jsons or writing to stage, hist)
  var currentTable = ""

  val CORRUPT_ROW_NAME = "_corrupt_record"
  val JSON_FILE_NAME_COL = "jsonFile"

  val datetimeFormatterJson = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH.mm")
  val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
  val datetimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")


  def getSparkSession(): SparkSession = {
    val spark = SparkSession
      .builder()
      .enableHiveSupport()
      //required for overwriting ONLY the required partitioned folders, and not the entire root folder
      .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
      //merge schemas of all parquet files instead of picking a random one
      .config("spark.sql.parquet.mergeSchema", "true")
      .getOrCreate()
    import spark.implicits._
    spark
  }

  def getFileSystem(spark: SparkSession): FileSystem = {
    val conf = spark.sparkContext.hadoopConfiguration
    FileSystem.get(conf)
  }

  // get list of files' paths by input path
  def getFilesList(path: String): List[String] = {
    out("INFO: Getting list of all JSON files...")
    var buff = new ListBuffer[String]()
    val iter = fs.listFiles(new Path(path), true)
    while(iter.hasNext){
      var fPath = iter.next().getPath.toString
      buff += fPath
    }
    buff.toList
  }

  // get file name without extension based on file's path
  def getFileName(path: String): String = {
    val fn = new Path(path).getName
    fn.slice(0, fn.lastIndexOf("."))
  }

  // get file's extension
  def getFileExtension(fileName: String): String = {
    fileName.slice(fileName.lastIndexOf(".")+1, fileName.length)
  }

  // check is string contaning date os specified format
  def isDateIsValid(dateStr: String, dFormat: DateTimeFormatter): Boolean = {
    Try(parseDate(dateStr, dFormat)) match {
      case Success(parsedDate) => true
      case _ => false
    }
  }

  // check file's extension
  def checkFileExtension(fileName: String, ext: String): Boolean = {
    getFileExtension(fileName) == ext
  }

  // check is Json file's name is correct or not
  // filePath - HDFS path of Json file
  def isJsonFileCorrect(filePath: String): Boolean = {
    var res = false
    val fName = new Path(filePath).getName
    //check if json-file has correct extension and valid date in file's name
    if(checkFileExtension(fName, "json") && isDateIsValid(getFileName(filePath), datetimeFormatterJson)){
      res = true
    }
    res
  }

  //filter only Json-files with "yyyy-MM-dd'T'HH.mm" format
  def validateJsonFiles(jsonFilePathList: List[String]): (List[String], List[String]) = {
    var validList = new ListBuffer[String]
    var notValidList = new ListBuffer[String]
    for(fPath <- jsonFilePathList){
      if(isJsonFileCorrect(fPath)){
        validList += fPath
      }
      else {
        notValidList += fPath
      }
    }
    (validList.toList, notValidList.toList)
  }

  // parse String to LocalDateTime
  def parseDate(str: String, frmt: DateTimeFormatter): LocalDateTime = {
    LocalDateTime.parse(str, frmt)
  }

  // filter out only file names which in specified time range
  def filterFileNames(fileList: List[String], dateFrom: LocalDateTime, dateTo: LocalDateTime): List[String] = {
    val filteredLst = fileList.filter(path =>
      checkDateInTimeRange(parseDate(getFileName(path), datetimeFormatterJson), dateFrom, dateTo))
    filteredLst
  }

  // check date in time range or not
  def checkDateInTimeRange(inputDate: LocalDateTime, dateFrom: LocalDateTime, dateTo: LocalDateTime): Boolean = {
    var res = false
    if((inputDate.isAfter(dateFrom) || inputDate.isEqual(dateFrom)) && inputDate.isBefore(dateTo)){
      res = true
    }
    res
  }

  // add system variable to Map
  def addSystemVar(sys_name: String, sys_val: String): Unit = {
    systemVarsMap += (sys_name -> sys_val)
    out(s"INFO: Added system variable: $sys_name = $sys_val")
  }

  def isEmpty(str: String): Boolean = {
    var res = true
    if(str != null){
      if(!str.trim.isEmpty){
        res = false
      }
    }
    res
  }

  def clearCurrentTableName(): Unit = {
    currentTable = ""
  }

  // get Spark application name
  def getAppName(spark: SparkSession): String = {
    spark.sqlContext.getAllConfs.get("spark.app.name") match {
      case Some(appName) => appName
      case None => "APLICATION_NAME_NOT_SET"
    }
  }

  def main(args: Array[String]): Unit = {

    val spark = getSparkSession()
    val argsMap = argsToOptionMap(args)

    fs = getFileSystem(spark)

    var isArgsExist = true
    for (i <- argsList) {
      if (!argsMap.keySet.toSet.contains(i)) {
        isArgsExist = false
        break()
      }
    }

    if (isArgsExist) {
      val date_from = argsMap.getOrElse("date_from", null)
      val date_to = argsMap.getOrElse("date_to", null)
      val db_config = argsMap.getOrElse("db_config", null)         // (import_jsons_to_stage_anketa.conf) basic configuration of inporting Json files to stage
      val db_config_env = argsMap.getOrElse("db_config_env", null) // (aml_env.conf) environment configuration (logging table conf, ...)
      val db_config_src = argsMap.getOrElse("db_config_src", null) // (src_tables.conf) source tables configuration
      launch_id = argsMap.getOrElse("launch_id", null)             // integration launch id
      in_unit = argsMap.getOrElse("unit", UNIT_DEFAULT)            // [optional] unit of imported data

      out("INFO: Arguments: ")
      out("|- launch_id:     " + launch_id)
      if(in_unit != UNIT_DEFAULT){
        out("|- unit:         " + in_unit)
      }
      else {
        out("|- unit: No filter source data by unit set up")
      }
      out("|- date_from:     " + date_from)
      out("|- date_to:       " + date_to)
      out("|- db_config:     " + db_config)
      out("|- db_config_env: " + db_config_env)

      // time interval of JSON files to be imported
      dateFrom = parseDate(date_from, datetimeFormatter)
      dateTo = parseDate(date_to, datetimeFormatter)

      //add system variables to Map
      addSystemVar(SysVar.SYS_DATE_CLOSE, dateTo.toLocalDate.format(dateFormatter))
      addSystemVar(SysVar.SYS_UNIT, in_unit)
      addSystemVar(SysVar.SYS_APP_NAME, getAppName(spark))

      // get config 'import_json_stl.conf'
      conf = loadFile(db_config)

      // get all data on importing data
      val inputConf = conf.getConfig("input.json")
      val outputConf = conf.getConfig("output")

      // get environment config (logging config)
      envConf = loadFile(db_config_env)
      logConf = envConf.getConfig("logging")

      // get source tables config
      srcTabsConf = loadFile(db_config_src)

      try {
        out("INFO: Start loading JSONs from HDFS...")
        getTablesHdfs(spark, inputConf)
        clearCurrentTableName()
        out("INFO: Loading succedded!")

        try {
          out("==============================================")
          out("INFO: Start writing DataFrame to Hive...")
          writeToHive(spark, outputConf)
          out("INFO: Writing to Hive succedded!")
        }
        catch {
          // error occured while preparing for STAGE area
          case saex: HandleStageException =>
            out("ERROR: Error occured while preparing data for STAGE area!")
            out("ERROR: Exception: " + saex.getMessage)
            logErrorEvent(spark, currentTable, EventType.WRITE_TO_STAGE, saex.getMessage)
          // error occured while preparing data for HIST area
          case hstex: HandleHistException =>
            out("ERROR: Error occured while preparing data for HIST area!")
            out("ERROR: Exception: " + hstex.getMessage)
            logErrorEvent(spark, currentTable, EventType.WRITE_TO_HIST, hstex.getMessage)
          // error occured while preparing data for Hive (e.g. table_name not set up in output.hive object in config)
          case hiveex: HandleHiveException =>
            out("ERROR: Error occurred while handling data for Hive!")
            out("ERROR: Exception: " + hiveex.getMessage)
            logErrorEvent(spark, currentTable, EventType.WRITE_TO_HIVE, hiveex.getMessage)
          // untracked system error occured
          case ex: Exception =>
            out("ERROR: System error while handling Json data: " + ex.getMessage)
            out("ERROR: Exception: " + ex.getMessage)
            logErrorEvent(spark, currentTable, EventType.SYS_ERROR, ex.getMessage)
        }
        finally {
          spark.stop()
        }
      }
      catch {
        case ex: Exception =>
          out("ERROR: Importing Json files failed: " + ex.getMessage)
          logErrorEvent(spark, currentTable, EventType.IMPORT_JSONS, ex.getMessage)
      }
      finally {
        spark.stop()
      }
    }
    spark.stop()
  }

  def readJsons(spark: SparkSession, jsonSchema: String, fileNamesList: List[String]): DataFrame = {
    spark.read.option("mode", "PERMISSIVE").schema(getJsonStruct(jsonSchema)).json(fileNamesList : _*)
  }

  // return DataFrame with file name per row
  def getSourceFileName(df: DataFrame): DataFrame = {
    df.withColumn(JSON_FILE_NAME_COL, input_file_name())
  }

  // return DataFrame with 'jsonFileName', '_corrupt_record' columns
  def getCorruptedRows(df: DataFrame): DataFrame = {
    df.select(JSON_FILE_NAME_COL, CORRUPT_ROW_NAME)
      .filter(col(CORRUPT_ROW_NAME).isNotNull)
  }

  def isDfEmpty(df: DataFrame): Boolean = {
    df.head(1).isEmpty
  }

  def toTimestamp(dt: LocalDateTime): Timestamp = {
    Timestamp.valueOf(dt)
  }

  def toDate(dt: LocalDate): Date = {
    Date.valueOf(dt)
  }

  def getCurrentTimestamp(): LocalDateTime = {
    LocalDateTime.now()
  }

  // write prepaired DataFrame to Log table
  def writeToLog(df: DataFrame): Unit = {
    out("INFO: Start writing to log table...")
    saveToTable(df, logConf, SaveMode.Append)
  }

  case class LogTable(launch_id: String = null,
                      unit: String = null,
                      table_schema: String = null,
                      table_name: String = null,
                      source_system: String = null,
                      status: String = null,
                      load_date_from: Timestamp = null,
                      load_date_to: Timestamp = null,
                      error_message: String = null,
                      json_file: String = null,
                      json_file_corrupted_rec: String = null,
                      day_close: Date = null,
                      load_timestamp: Timestamp = null,
                      event_type: String = null,
                      app_name: String = null
  )

  /** Generate DataFrame containing information about Json corrupted rows
    *
    * @param spark SparkSession
    * @param df DataFrame with corrupted rows with two columns (record source file name, corrupt row name)
    * @param tableName Table Name which Json data is handled
    * @return DataFrame with corrupted Json rows enriched with meta information
    */
  def getCorruptedRowsDf(spark: SparkSession, df: DataFrame, tableName: String): DataFrame = {
    // get table meta information of specified table
    //val tableMeta: Map[String, String] =
    var tableSchema = "NO_INFO"
    var sourceSystem = "NO_INFO"
    val tblName = if(isEmpty(tableName)) "NO_INFO" else tableName

    getTableMeta(tableName) match {
      case Some(tableMeta) =>
        tableSchema = tableMeta.getOrElse("tableSchema", "no_schema")
        sourceSystem = tableMeta.getOrElse("sourceSystem", "no_source")
      case None =>
    }

    val corruptDf = df
        // get from spark-submit
        .withColumn("app_name", lit(systemVarsMap(SysVar.SYS_APP_NAME)))
        .withColumn("launch_id", lit(launch_id))
        .withColumn("load_date_from", lit(toTimestamp(dateFrom)))
        .withColumn("load_date_to", lit(toTimestamp(dateTo)))
        .withColumn("day_close", lit(toDate(dateFrom.toLocalDate)))
        // get from Config
        .withColumn("table_schema", lit(tableSchema))
        .withColumn("table_name", lit(tblName))
        .withColumn("source_system", lit(sourceSystem))
        .withColumn("unit", lit(systemVarsMap(SysVar.SYS_UNIT)))
        // constants
        .withColumn("event_type", lit(EventType.IMPORT_JSONS))
        .withColumn("status", lit(EventStatus.ERROR))
        .withColumn("load_timestamp", lit(current_timestamp()))
        // calculate
        .withColumnRenamed(JSON_FILE_NAME_COL, "json_file")
        .withColumnRenamed(CORRUPT_ROW_NAME, "json_file_corrupted_rec")
    corruptDf
  }


  /** Based on DataFrame with parsed Json files content get and log corrupted records
    *
    * @param spark SparkSession
    * @param df DataFrame with parsed Json files
    * @param tableName table name which is handled
    * @return Boolean is json files has or not corrupted records
    */
  def handleJsonCorruptedRows(spark: SparkSession, df: DataFrame, tableName: String): Boolean = {
    var jsonsIsCorrupted = false
    // get DataFrame with source file name per record
    val df_out = getSourceFileName(df)
    // logging table configuration
    val logConf = envConf.getConfig("logging")
    // get DataFRame with corrupted records and source file names
    val corruptRowsDf = getCorruptedRows(df_out)

    // if corrupted records exists, we write corrupted records with additional meta information to logging table
    if(!isDfEmpty(corruptRowsDf)){
      val logCorruptRowsDf = getCorruptedRowsDf(spark, corruptRowsDf, tableName)
      out("INFO: Writing Json corrupted records to log tables...")
      writeToLog(logCorruptRowsDf)
      jsonsIsCorrupted = true
    }
    jsonsIsCorrupted
  }

  // delete currupted records after reading jsons
  def dropCurruptRecords(df: DataFrame): DataFrame = {
    out("INFO: Removing Json corrupted records...")
    df.select("*").filter(col(CORRUPT_ROW_NAME).isNull).drop(col(CORRUPT_ROW_NAME))
  }

  // return source table meta as Map
  def getSourceTableMeta(tableName: String): Map[String, String] = {
    var metaMap = Map.empty[String, String]
    //source table meta conf
    val metaConf = srcTabsConf.getConfig("tables." + tableName)

    val sourceSystem = metaConf.getString("sourceSystem")
    val jsonSchema = metaConf.getString("jsonSchema")
    val replicatedByUnit = if(metaConf.hasPath("replicatedByUnit")) metaConf.getString("replicatedByUnit") else "false"
    var tableSchema: String = ""
    var tablePath: String = ""

    // if unit is not specified in spark-submit
    if(systemVarsMap(SysVar.SYS_UNIT) == UNIT_DEFAULT){
      tableSchema = if(metaConf.hasPath("tableSchema")) metaConf.getString("tableSchema") else null
      tablePath = metaConf.getString("tablePath")
    }
    else {
      val unitConf = metaConf.getConfig(systemVarsMap(SysVar.SYS_UNIT))
      tableSchema = if(unitConf.hasPath("tableSchema")) unitConf.getString("tableSchema") else null
      tablePath = unitConf.getString("tablePath")
    }
    metaMap += ("sourceSystem" -> sourceSystem)
    metaMap += ("jsonSchema" -> jsonSchema)
    metaMap += ("tableSchema" -> tableSchema)
    metaMap += ("tablePath" -> tablePath)
    metaMap += ("replicatedByUnit" -> replicatedByUnit)
    metaMap
  }

  // get meta information about specified table
  def getTableMeta(tableName: String): Option[Map[String, String]] = {
    srcTablesMeta.get(tableName)
  }


  // log successful event
  def logSuccessEvent(spark: SparkSession, tableName: String, eventType: String): Unit = {
    out("INFO: Logging success event...")
    out("INFO: |- tableName: " + tableName)
    logEvent(spark, tableName, EventStatus.SUCCESS, eventType)
  }

  // log error event
  def logErrorEvent(spark: SparkSession, tableName: String, eventType: String, errorMessage: String): Unit = {
    out("INFO: Logging error event...")
    out("INFO: |- tableName: " + tableName)
    out("INFO: |- error_message: " + errorMessage)
    logEvent(spark, tableName, EventStatus.ERROR, eventType, errorMessage)
  }

  // format error message
  def getErrorMessage(mess: String): String = {
    if(isEmpty(mess)){
      EMPTY_ERR_MESSAGE
    }
    else {
      mess.slice(0, 149)
    }
  }

  /** Log event (error, warning, success) during integration
    *
    * @param spark SparkSession
    * @param tableName table name by which we get meta information about source data (table path, source system, etc.)    *
    * @param eventStatus event status (EventStatus enum)
    * @param eventType event type (EventType enum)
    * @param errorMessage event message (error, warning, successful)
    */
  def logEvent(spark: SparkSession, tableName: String, eventStatus: String, eventType: String, errorMessage: String = null): Unit = {
    out("INFO: Writing event to log table...")

    out("INFO: |- tableName: " + tableName)
    val errMessage = getErrorMessage(errorMessage)
    out("INFO: |- error_message: " + errMessage)

    // get table meta information
    val tableMeta: Option[Map[String, String]] = getTableMeta(tableName)
    val errorDf = getEventMessage(spark, tableName, tableMeta, errMessage, eventStatus, eventType)
    writeToLog(errorDf)
    out("INFO: Writing succeeded!")
  }

  /** Generate DataFrame with event information to be written to log table
    *
    * @param spark SparkSession
    * @param tableMeta meta information about source data (json's path, table's name, etc.)
    * @param error_message event message (error, warning, successful)
    * @param eventStatus event status (EventStatus enum)
    * @param eventType event type (EventType enum)
    * @return DataFrame with event information
    */
  def getEventMessage(spark: SparkSession, tableName: String, tableMeta: Option[Map[String, String]], error_message: String, eventStatus: String, eventType: String): DataFrame = {
    var table_schema = ""
    var source_system = ""
    var tblName = ""

    tableMeta match {
        // table's meta data is found by table name
      case Some(tblMeta) =>
        table_schema = tblMeta.getOrElse("tableSchema", NO_INFO)
        source_system = tblMeta.getOrElse("sourceSystem", NO_INFO)
        tblName = tableName
        // table's meta data not found by specified table name
      case None =>
        table_schema = NO_INFO
        source_system = NO_INFO
        tblName = "TABLE_NAME_NOT_FOUND"
    }
    val errMessageLst = List(
      LogTable(
        // get from spark-submit
        app_name = systemVarsMap(SysVar.SYS_APP_NAME),
        launch_id = launch_id,
        load_date_from = toTimestamp(dateFrom),
        load_date_to = toTimestamp(dateTo),
        day_close = toDate(dateFrom.toLocalDate),
        // get from Config
        table_schema = table_schema,
        table_name = tblName,
        source_system = source_system,
        unit = systemVarsMap(SysVar.SYS_UNIT),
        // constants
        event_type = eventType,
        status = eventStatus,
        error_message = error_message,
        load_timestamp = toTimestamp(getCurrentTimestamp())
      )
    )
    spark.createDataFrame(errMessageLst)
  }

  // check if HDFS path exists
  def checkPathExists(path: String): Boolean = {
    fs.exists(new Path(path))
  }

  /** Get Json-files' paths and run checks
    *
    * @param spark SparkSession
    * @param tableName table name by which we get meta information about source data (table path, source system, etc.)
    * @return list of Json-files paths to be imported
    */
  def getJsonPathList(spark: SparkSession, tableName: String): List[String] = {
    // get table's meta information
    val tblMetaMap = getTableMeta(tableName)
    // check if HDFS path with Json files exists
    if(!checkPathExists(tblMetaMap.get("tablePath"))){
      val errMess = "HDFS path does not exist: " + tblMetaMap.get("tablePath")
      throw new Exception(errMess)
    }
    // get list of all json-files (with paths)
    out("INFO: Listing files in HDFS: " + tblMetaMap.get("tablePath"))
    val jsonFilesList: List[String] = getFilesList(tblMetaMap.get("tablePath"))
    out("INFO: Count all files in HDFS dir: " + jsonFilesList.size)

    //check Json's files' names in HDFS
    out("INFO: Start validating json files...")
    val (validJsonPathLst, notValidJsonPathLst) = validateJsonFiles(jsonFilesList)
    out("INFO: |- number of valid json files:     " + validJsonPathLst.size)
    out("INFO: |- number of not valid json files: " + notValidJsonPathLst.size)

    if(!notValidJsonPathLst.isEmpty){
      out("INFO: Not valid json files: ")
      notValidJsonPathLst.foreach(println)
    }
    // throw exception when there are not correct json files and write to log
    if(validJsonPathLst.isEmpty){
      val errMess = s"No correct Json files exist in " + tblMetaMap.get("tablePath") + ". Number of files in directory: " + jsonFilesList.size
      throw new Exception(errMess)
    }

    out("INFO: Filtering JSON files...")
    val filteredFilesNamesList: List[String] = filterFileNames(validJsonPathLst, dateFrom, dateTo)
    out("INFO: Count of filtered JSON files: " + filteredFilesNamesList.size)

    // throw exception if there's not any json files in specified time period
    if(filteredFilesNamesList.isEmpty){
      val errMess = s"No Json files exist in time period [${dateFrom.format(datetimeFormatter)}; ${dateTo.format(datetimeFormatter)}). Directory contains ${jsonFilesList.size} json files."
      throw new Exception(errMess)
    }
    filteredFilesNamesList
  }

  // load JSONs from HDFS into DataFrames with tempName
  def getTablesHdfs(spark: SparkSession, conf: Config): Unit = {
    val tablesPathConf = conf.getConfigList("tables")
    val tables = new Array[DataFrame](tablesPathConf.size())
    val iterator = tablesPathConf.iterator()
    var i = 0

    while(iterator.hasNext){
      val entry = iterator.next()
      val sourceConf = entry.getConfig("source") // source table meta config
      val sqlConf = entry.getConfig("sql")       // sql transformation of source data

      val tableName = setTableName(sourceConf)
      val tempName = sourceConf.getString("tempName")

      // get table meta
      val tblMetaMap: Map[String,String] = getSourceTableMeta(tableName)
      tblMetaMap += ("tableName" -> tableName)
      // add table meta information to common Map
      srcTablesMeta += (tableName -> tblMetaMap)

      out("INFO: Source table meta config:")
      out("INFO: |- tableName: " + tableName)
      for((k,v) <- tblMetaMap){
        out(s"INFO: |- $k:   $v")
      }

      // run Json checks get Json files path to be imported
      val jsonPathList: List[String] = getJsonPathList(spark, tableName)

      out("INFO: Json-files were read: ")
      jsonPathList.foreach(println)

      out("INFO: Start reading JSON files' content...")
      out("INFO: |- Json schema: " + tblMetaMap("jsonSchema"))

      // read Json files with captured rows
      // DataFrame(key, value, offset, timestamp, _corrupt_record)
      tables(i) = readJsons(spark, tblMetaMap("jsonSchema"), jsonPathList)

      out("INFO: DataFrame (read Jsons): ")
      out("info: |- Partitions number: " + tables(i).rdd.getNumPartitions)
      printDfSchema(tables(i))

      out("INFO: Start logging importing Jsons...")
      val jsonsIsCorrupted = handleJsonCorruptedRows(spark, tables(i), currentTable)

      if(jsonsIsCorrupted){
        out("INFO: Json corrupted records exist. Start removing corrupted records.")
        tables(i) = dropCurruptRecords(tables(i))
      }
      else {
        out("INFO: Json corrupted records [NOT] exist")
      }
      tables(i).createOrReplaceTempView(tempName)

      // show specified number of items of DataFrame containing JSONs
      showDf(tables(i), sourceConf)
      out("info: |- Partitions number: " + tables(i).rdd.getNumPartitions)
      printDfSchema(tables(i))

      tables(i) = makeDf(spark, sqlConf)
      tables(i).createOrReplaceTempView(tempName)

      // write success event is no Json corrupted records exists
      if(!jsonsIsCorrupted){
        logSuccessEvent(spark, currentTable, EventType.IMPORT_JSONS)
      }
      i=i+1
      out("==============================================")
      out("INFO: Importing JSON files is DONE!")
      out("==============================================")
    }
  }

  // get StructType from String JSON
  def getJsonStruct(jsonSchema: String): StructType = {
    DataType.fromJson(jsonSchema).asInstanceOf[StructType].add(CORRUPT_ROW_NAME, StringType)
  }

  // print DataFrame schema
  def printDfSchema(df: DataFrame): Unit = {
    out("INFO: |- Print schema: \n")
    df.printSchema
  }

  // return string with substituted values from system variables
  def replaceWithSysVar(str: String): String = {
    var strOut = str
    for((sys_name, sys_val) <- systemVarsMap){
      strOut = strOut.replaceAll(sys_name, sys_val)
    }
    strOut
  }

  // run SQL query from Config
  def getQueriedDf(spark: SparkSession, conf: Config): DataFrame = {
    val query = replaceWithSysVar(conf.getString("query"))
    out("INFO: Running query: \n" + query)
    queryDf(spark, query)
  }

  // cache DataFrame if specifies in 'sql' Config
  def cacheDf(df: DataFrame, conf: Config): DataFrame ={
    if(conf.hasPath("cache") && conf.getBoolean("cache")){
      out("INFO: DataFrame is persisted!")
      cacheDf(df)
    }
    df
  }
  // cache DataFrame
  def cacheDf(df: DataFrame): DataFrame ={
    df.persist(StorageLevel.MEMORY_AND_DISK)
  }

  // transform JSON's based on config
  def makeDf(spark: SparkSession, config: Config): DataFrame = {
    out("INFO: Start making DataFrame...")
    // [required] run SQL query
    var df = getQueriedDf(spark, config)
    printDfSchema(df)
    // [optional] make windowed DataFrame
    df = makeWindowDf(df, config)

    if(config.hasPath("tempName")){
      out("INFO: |- tempName: " + config.getString("tempName"))
      df.createOrReplaceTempView(config.getString("tempName"))
    }

    // cache DataFrame if specifies in 'sql' Config
    df = cacheDf(df, config)
    // [optional] show specified number of items of DataFrame containing JSONs
    showDf(df, config)
    // [optional] count DataFrame's rows if specified
    countDf(df, config)
    df
  }

  // run 'query' from config over DataFrame
  def queryDf(spark: SparkSession, query: String): DataFrame = {
    spark.sqlContext.sql(query)
  }

  // apply window to DataFrame
  def makeWindow(df: DataFrame, lstCol: List[String], sortCol: String): DataFrame = {
    val w = Window.partitionBy(lstCol.head, lstCol.tail: _*).orderBy(df.col(sortCol).desc)
    val dfTop = df.withColumn("rn", row_number.over(w)).where(col("rn") === 1).drop("rn")
    dfTop
  }

  // get windowed DataFrame
  def makeWindowDf(df: DataFrame, conf: Config): DataFrame = {
    val df_out = if (conf.hasPath("window.sortColumn") && conf.hasPath("window.columns")){
      out("INFO: Creating windowed DataFrame...")
      val sortColumn = conf.getString("window.sortColumn")
      val colList: List[String] = conf.getStringList("window.columns").toList
      out("|- window.sortColumn: " + sortColumn)
      out("|- window.columns:    " + colList.mkString(", "))
      makeWindow(df, colList, sortColumn)
    }
    else df
    df_out
  }

  // print DataFrame
  def showDf(df: DataFrame, conf: Config): Unit = {
    if(conf.hasPath("show") && conf.hasPath("show.limit")){
      out("INFO: Show " + conf.getInt("show.limit") + " rows of DF: \n")
      df.limit(conf.getInt("show.limit")).show(false)
    }
  }

  // count DataFrame rows
  def countDf(df: DataFrame, conf: Config): Unit = {
    if(conf.hasPath("count") && conf.getBoolean("count")){
      out("INFO: Number of rows in DataFrame: " + df.count())
    }
  }

  // return partitioned DataFrame based on Config
  def partitionDf(df: DataFrame, config: Config): (DataFrame, List[String]) = {
    var df_out = df
    var partitionLst = List.empty[String]

    if (config.hasPath("partitionBy")){
      partitionLst = config.getStringList("partitionBy").toList
      out("INFO: Partition by: " + partitionLst.mkString(", "))

      df_out = df_out.repartition(partitionLst.map(col(_)): _*)
    }
    printDfSchema(df_out)
    (df_out, partitionLst)
  }

  // save { partitionBy = [""], tablePath = ""}
  // save data to HDFS as partitioned DataFrame in parquet format
  def saveToTable(df: DataFrame, config: Config, saveMode: SaveMode): Unit = {
    out("INFO: Start saving DataFrame to table...")
    val tablePath = config.getString("tablePath")

    // get partitioned or not dataframe and list of partitioned keys
    val (df_out, partitionLst) = partitionDf(df, config)

    if(partitionLst.isEmpty){
      out("INFO: Writing [NOT] partitioned DataFrame to table...")
      saveToHdfs(df_out, saveMode, tablePath)
    }
    else {
      out("INFO: Writing partitioned DataFrame to table...")
      saveToHdfs(df_out, saveMode, tablePath, partitionLst)
    }
    out("INFO: Writing is OVER")
  }

  // prepare DataFrame for writing to Stage
  def writeToHiveStage(spark: SparkSession, config: Config): Unit = {
    out("INFO: Start preparing Stage DataFrame...")
    val df = makeDf(spark, config.getConfig("sql"))
    saveToTable(df, config.getConfig("save"), SaveMode.Overwrite)
  }

  def readHdfs (spark: SparkSession, path: String): Try[DataFrame] = {
    out("INFO: Reading data from path: " + path)
    Try(readParquet(spark, path))
  }

  def readParquet(spark: SparkSession, path: String): DataFrame = {
    spark.read.format("parquet").load(path)
  }

  // read parquet data from HDFS based on Config
  def readFromHdfs(spark: SparkSession, conf: Config): DataFrame = {
    val tablePath = conf.getString("tablePath")
    val tempName = conf.getString("tempName")

    out("INFO: |- tablePath: " + tablePath)
    out("INFO: |- tempName:  " + tempName)

    var df_out = readParquet(spark, tablePath)
    df_out.createOrReplaceTempView(tempName)
    df_out
  }

  // get data for calculating Hist
  def getTempTables (spark: SparkSession, conf: Config): Unit = {
    out("INFO: Run transformation: ")
    val tablesList = conf.getConfigList("input")
    val tables = new Array[DataFrame](tablesList.size())
    val iterator = tablesList.iterator()
    var i = 0
    while(iterator.hasNext){
      val entry = iterator.next()

      if(entry.hasPath("source")){
        out("INFO: Read data from HDFS ('output.hive.hist.input.source')")
        tables(i) = readFromHdfs(spark, entry.getConfig("source"))
      }
      if(entry.hasPath("sql")){
        out("INFO: Run sql transformation ('output.hive.hist.input.sql')")
        tables(i) = makeDf(spark, entry.getConfig("sql"))
      }
      // cache DataFrame if cache = true is specified
      cacheDf(tables(i), entry)
      i=i+1
    }
  }

  // prepare DataFrame for writing to Stage
  def writeToHiveHist(spark: SparkSession, conf: Config): Unit = {
    out("INFO: Start preparing Hist DataFrame...")
    // if additional source data is configured
    if(conf.hasPath("input")){
      out("INFO: Run block 'hist.input'")
      getTempTables(spark, conf)
      out("INFO: Transformation block is OVER!")
    }

    // if you need to 'update' specified partition apart from unit
    if(conf.hasPath("updatePartition")){
      out("INFO: 'updatePartition' block is configured:")
      updateDf(spark, conf)
    }
    else {
      out("INFO: 'updatePartition' block is [NOT] configured!")
      handleTransactions(spark, conf)
    }

    // prepare DataFrame (hive.hist.sql) based on views to write to HDFS
    val dfToWhiteHist = makeDf(spark, conf.getConfig("sql"))
    saveToTable(dfToWhiteHist, conf.getConfig("save"), SaveMode.Overwrite)
    out("INFO: Saving succedded!")
  }

  // return DataFrame by view name
  def getDfByName(spark: SparkSession, tempName: String): DataFrame = {
    spark.sql("SELECT * FROM " + tempName)
  }

  // filter DataFrame by unit
  def filterByUnit(df: DataFrame): DataFrame = {
    df.filter(col("unit") === systemVarsMap(SysVar.SYS_UNIT))
  }

  //reorder DataFrame's columns according to another DataFrame
  def reorderCols(dfToOrder: DataFrame, dfByOrder: DataFrame): DataFrame = {
    val colsByOrder = dfByOrder.columns.toList
    dfToOrder.select(colsByOrder.head, colsByOrder.tail: _*)
  }

  // return string of transactions' types from src_tables.conf
  def getTransactTypesList(tranType: String, conf: Config): List[String] = {
    val tranTypesLst: List[String] = conf.getStringList(tranType).toList
    if(tranTypesLst.isEmpty){
      throw new Exception(s"transactions.$tranType is empty!")
    }
    out("INFO: |- transactions." + tranType + ": " + tranTypesLst.mkString(", "))
    tranTypesLst
  }

  // return column containing transaction type name
  def getTransactColName: String = {
    // column containing transaction type value
    val tranCol = srcTabsConf.getString("transactions.columnName").trim()
    if(tranCol.isEmpty){
      val err_mess = "transactions.columnName is empty!"
      throw new Exception(err_mess)
    }
    out("INFO: |- transactions.columnName: " + tranCol)
    tranCol
  }

  // filter transactions by specified transact type
  def getTransactByType(df: DataFrame, tranType: String): DataFrame = {
    // transaction configuration
    val srcTabTransactConf = srcTabsConf.getConfig("transactions")
    df.filter(col(getTransactColName).isin(getTransactTypesList(tranType, srcTabTransactConf): _*))
  }

  // add column to dataframe with 'colName' column with current timestamp
  def addCurrTimestampCol(df: DataFrame, colName:String): DataFrame = {
    df.withColumn(colName, lit(toTimestamp(getCurrentTimestamp())))
  }

  // return DataFrame with data from STAGE filtered by transaction types specified in src_tables.conf
  def getTransactByTypeDF(srcTablDf: DataFrame, windowConf: Config, tranType: String): DataFrame = {
    out("INFO: Start preparing DataFrame with transaction type: " + tranType)

    tranType match {
      case tranType @ TransactTypes.INSERT =>
        out("INFO: Start filtering by INSERTS types")
        // filter STAGE data only specified transaction types (insert or delete)
        var stageInsertDf = getTransactByType(srcTablDf, tranType)
        // get last rows from INSERT transactions
        stageInsertDf = makeWindowDf(stageInsertDf, windowConf)
        // set flag 'is_deleted' = 0 (row is active)
        stageInsertDf = setRowStatus(stageInsertDf, RowStatus.IS_ACTIVE)
        // add column 'is_deleted_modified' with current timestamp
        stageInsertDf = addCurrTimestampCol(stageInsertDf, IsDeletedFlag.MODIFIED)
        stageInsertDf

      case tranType @ TransactTypes.DELETE =>
        out("INFO: Start filtering by DELETES types")
        var stageDeleteDf = getTransactByType(srcTablDf, tranType)
        stageDeleteDf = makeWindowDf(stageDeleteDf, windowConf)
        stageDeleteDf = setRowStatus(stageDeleteDf, RowStatus.IS_DELETED)
        // add column 'is_deleted_crated' with current timestamp
        stageDeleteDf = addCurrTimestampCol(stageDeleteDf, IsDeletedFlag.CREATED)
        stageDeleteDf
    }
  }

  // return DataFrame with INSERT data updated with DELETE transactions (column 'is_deleted')
  def updateRowsStatus(insertDf: DataFrame, deleteDf: DataFrame, joinColList: List[String], sortColumn: String): DataFrame = {
    insertDf.as("ins")
      .join(broadcast(deleteDf.as("del")), joinColList, "left")

      .select(col("ins.*"),
        when(col("del." + sortColumn).isNotNull && col("del." + sortColumn) >  col("ins." + sortColumn), col("del." + IsDeletedFlag.NAME)).otherwise(col("ins." + IsDeletedFlag.NAME)).alias(IsDeletedFlag.NAME + "_tmp"),
        // value of 'is_deleted_created' from DELETE transaction update 'is_delete_modified' of INSERT transaction when row is specified as deleted
        when(col("del." + sortColumn).isNotNull && col("del." + sortColumn) >  col("ins." + sortColumn), col("del." + IsDeletedFlag.CREATED)).otherwise(col("ins." + IsDeletedFlag.MODIFIED)).alias(IsDeletedFlag.MODIFIED + "_tmp"))

      .drop(IsDeletedFlag.NAME)
      .drop(IsDeletedFlag.MODIFIED)
      .withColumnRenamed(IsDeletedFlag.NAME + "_tmp", IsDeletedFlag.NAME)
      .withColumnRenamed(IsDeletedFlag.MODIFIED + "_tmp", IsDeletedFlag.MODIFIED)

      .withColumn(IsDeletedFlag.NAME, col(IsDeletedFlag.NAME).cast(new DecimalType(1)))
  }

  // return DataFrame with data from STAGE including insert and delete transactions' types
  def handleTransactDeleteType(windowConf: Config, insertDf: DataFrame, deleteDf: DataFrame): DataFrame = {
    out("INFO: Start handling deletes...")
    val pkList: List[String] = windowConf.getStringList("window.columns").toList
    val sortColumn = windowConf.getString("window.sortColumn") // source_timestamp

    out("INFO: |- primary keys: " + pkList.mkString(", "))
    out("INFO: |- sortColumn:   " + sortColumn)

    out("INFO: Start joining INSERT_DF and DELETE_DF...")
    var joinedDf = insertDf.join(broadcast(deleteDf), pkList, "left")
    printDfSchema(joinedDf)
    // update 'is_deleted' flag in INSERT transactions according to DELETE transactions
    updateRowsStatus(insertDf, deleteDf, pkList, sortColumn)
  }

  def setRowStatus(df: DataFrame, rowStatus: Integer): DataFrame = {
    df.withColumn(IsDeletedFlag.NAME, lit(rowStatus))
  }

  // handle different transaction types when no update partitons required
  def handleTransactions(spark: SparkSession, integrationConf: Config): Unit = {
    // check if transaction handling is configures correctly
    if(checkTransactConfigured(integrationConf)){
      out("INFO: Transaction handling is configured")
      val tranConf = integrationConf.getConfig("transactions")
      val tranSrc = tranConf.getString("source")
      val tranTarget = tranConf.getString("target")

      out("INFO: |- source:            " + tranSrc)
      out("INFO: |- target:            " + tranTarget)

      val stageAllDf = getDfByName(spark, tranSrc)  // DataFrame with data from STAGE with all transactions' types

      if(!isDfEmpty(stageAllDf)) {
        out("INFO: STAGE data exists for preparing HIST")
        var stageLastRows = getInsertTransactDf(spark, tranConf, stageAllDf)

        if(checkTransactConfigured(integrationConf, TransactTypes.DELETE)){ // check if DELETE transactions configured to be handled
          out("INFO: Handling 'DELETE' transaction types is configured")
          stageLastRows = getDeleteTransactDf(spark, tranConf, stageAllDf, stageLastRows)
        }
        stageLastRows.createOrReplaceTempView(tranTarget)
      }
      else {
        out("WARN: STAGE data [NO] exists for preparing HIST")
        throw new Exception ("There is no STAGE data exists for preparing HIST")
      }
    }
    else {
      val mess = "Transaction handling is [NOT] configured"
      out("INFO: " + mess)
    }
  }

  // union two DataFrames
  def unionDf(df1: DataFrame, df2: DataFrame, windowConf: Config): DataFrame = {
    val orderedDf1 = reorderCols(df1, df2)
    val unionedDf = orderedDf1.union(df2)
    makeWindowDf(unionedDf, windowConf)
  }

  // return HIST DataFrame with partitions to be updated
  def getHistPartitionsToUpdate(spark: SparkSession, saDf: DataFrame, histDf: DataFrame, updateKey: String): DataFrame = {
    // get list of partitions to be updated in Hist
    val partitionToUpd = cacheDf(saDf.filter(col(updateKey).isNotNull).select(updateKey).distinct)
    partitionToUpd.createOrReplaceTempView("partitionToUpd")

    out("INFO: Partitions coming from Stage incremental data: ")
    partitionToUpd.show(false)

    // filter Hist by unit (or get all data (unit = 'NO_UNIT'))
    out("INFO: Filtering Hist by unit: " + systemVarsMap(SysVar.SYS_UNIT))
    val filteredHist = filterByUnit(histDf)
    filteredHist.createOrReplaceTempView("filteredHist")

    out("INFO: Hist partitions to be updated: ")
    val histPartitionsToUpdList = spark.sql(s"SELECT $updateKey FROM partitionToUpd sa WHERE $updateKey IN (SELECT $updateKey FROM filteredHist)")
    histPartitionsToUpdList.show(false)

    out("INFO: Hist partitions to be inserted: ")
    val histPartitionsToInsertList = spark.sql(s"SELECT $updateKey FROM partitionToUpd sa WHERE $updateKey NOT IN (SELECT $updateKey FROM filteredHist)")
    histPartitionsToInsertList.show(false)

    //get Hist data filtered by new partitions from increment
    spark.sql(s"SELECT * FROM filteredHist WHERE $updateKey IN (SELECT $updateKey FROM partitionToUpd)")
  }

  // check if all tequired configuration is configured or not
  def checkTransactConfigured(conf: Config): Boolean = {
    var res: Boolean = false
    // if integration config (json to stage has INSERT transaction handling configuration)
    if(checkTransactConfigured(conf, TransactTypes.INSERT)){
      // check if 'transactions' object exists in src_tables.conf
      if (srcTabsConf.hasPath("transactions")) {
        val tranSrcConf = srcTabsConf.getConfig("transactions")
        // check if 'transactions.columnName' object exists in src_tables.conf
        if (tranSrcConf.hasPath("columnName") && !tranSrcConf.getString("columnName").trim.isEmpty) {
          if(tranSrcConf.hasPath(TransactTypes.INSERT)){
            val tranList = tranSrcConf.getStringList(TransactTypes.INSERT)
            // check if Config is an instance of List[String]
            if(!tranSrcConf.isEmpty){
              res = true
            }
          }
        }
      }
    }
    res
  }

  // check if transaction handling is configured or not
  def checkTransactConfigured(conf: Config, tranType: String): Boolean = {
    if(conf.hasPath("transactions")){
      val tranConf = conf.getConfig("transactions")
      tranType match {
        case TransactTypes.INSERT => tranConf.hasPath("handleInsertType") && tranConf.getBoolean("handleInsertType")
        case TransactTypes.DELETE => tranConf.hasPath("handleDeleteType") && tranConf.getBoolean("handleDeleteType")
      }
    }
    else {
      false
    }
  }

  // return DataFrame with INSERT transactions
  // if pathToHist is specified, then update STAGE data with data from HIST
  def getInsertTransactDf(spark: SparkSession, updConf: Config, sourceDf: DataFrame, pathToHist: String = null): DataFrame = {
    var insertDf = getTransactByTypeDF(sourceDf, updConf, TransactTypes.INSERT)
    // check if data with INSERT transaction types exist
    if(!isDfEmpty(insertDf)){
      out("INFO: INSERT transactions exist in STAGE")
      // if required to update HIST data
      if(pathToHist != null){
        val updParKey = updConf.getString("partitionToUpdate")
        val histTableDf: Try[DataFrame] = readHdfs(spark, pathToHist)
        histTableDf match {
          // data exists in HIST
          case Success(histDf) =>  // return last rows from (STAGE (INSERT) + HIST)
            val histToUpdateDf = getHistPartitionsToUpdate(spark, insertDf, histDf, updParKey) // HIST partitions required to update
            insertDf = unionDf(insertDf, histToUpdateDf, updConf)                             // union STAGE (INSERT) and HIST
          // data [NOT] exists in HIST
          case Failure(ex) =>     // return last rows from (STAGE (INSERT))
            out("WARN: No data exists in Hist. Getting data from Stage")
            out("WARN: Print ex: " + ex.getMessage)
        }
      }
    }
    else { // data with INSERT transaction types don't exist
      out("WARN: INSERT transactions [NOT] exists")
      out("INFO: Transactions handling is over.")
      throw new Exception ("There is no INSERT transaction types in STAGE exists")
    }
    insertDf
  }

  // return DataFrame with updated 'is_deleted' flag according to new DELETE transactions
  def getDeleteTransactDf(spark: SparkSession, updConf: Config, sourceDf: DataFrame, dfToUpdate: DataFrame): DataFrame = {
      val stageDeleteDf = getTransactByTypeDF(sourceDf, updConf, TransactTypes.DELETE)
    if(!isDfEmpty(stageDeleteDf)){
      out("INFO: DELETE transactions exist in STAGE data")
      // if there's DELETE transactions update INSERT df with DELETE
      handleTransactDeleteType(updConf, dfToUpdate, stageDeleteDf)
    }
    else {
      // if there isn't DELETE transactions return INSERT df
      out("INFO: DELETE transactions [NO] exist in STAGE data")
      dfToUpdate
    }
  }

  // return DataFrame (new increment from stage and hist)
  def updateDf(spark: SparkSession, integrationConf: Config): Unit = {
    out("INFO: Start updating...")
    val updConf = integrationConf.getConfig("updatePartition")
    val updSource = updConf.getString("source")
    val updTarget = updConf.getString("target")
    val updParKey = updConf.getString("partitionToUpdate")
    out("INFO: |- source:            " + updSource)
    out("INFO: |- target:            " + updTarget)
    out("INFO: |- partitionToUpdate: " + updParKey)

    // HIST data location
    val histTablePath = integrationConf.getString("save.tablePath")
    out("INFO: Hist table path:   " + histTablePath)

    // get STAGE (all transactions)
    val saIncrDf = getDfByName(spark, updSource)

    if(!isDfEmpty(saIncrDf)){
      out("INFO: STAGE data exists for preparing HIST")

      if(checkTransactConfigured(updConf)){    // check if transaction handling is configures correctly
        out("INFO: Transaction handling is configured")
        var updatedDf = getInsertTransactDf(spark, updConf, saIncrDf, histTablePath)  // get DataFrame with INSERT transactions

        if(checkTransactConfigured(updConf, TransactTypes.DELETE)) { // check if DELETE transactions configured to be handled
          out("INFO: Handling 'DELETE' transaction types is configured")
          updatedDf = getDeleteTransactDf(spark, updConf, saIncrDf, updatedDf)
        }
        updatedDf.createOrReplaceTempView(updTarget)
      }
      else {
        val mess = "Transaction handling is [NOT] configured"
        out("INFO: " + mess)
        out("INFO: Writing STAGE data to HIST without update")
        saIncrDf.createOrReplaceTempView(updTarget)
      }
    }
    else {
      out("WARN: STAGE data [NO] exists for preparing HIST")
      throw new Exception ("There is no STAGE data exists for preparing HIST")
    }
  }

  // check if table name is set up in config
  def setTableName(config: Config): String = {
    if(config.hasPath("tableName")) {
      currentTable = config.getString("tableName")
      out("INFO: currentTable: " + currentTable)
    }
    else {
      throw new HandleHiveException("Table name is not set in Config section")
    }
    currentTable
  }

  /** Run handling output.hive Config to write data to Hive
    *
    * @param spark SparkSession
    * @param config Config object output.hive with configuration of writing to Hive
    * @param hiveArea HiveArea enum (stage or hisr area)
    */
  def runWritingToHive(spark: SparkSession, config: Config, hiveArea: String): Unit = {
    hiveArea match {
      case area @ HiveArea.STAGE =>
        try {
          writeToHiveStage(spark, config.getConfig(area))
          logSuccessEvent(spark, currentTable, EventType.WRITE_TO_STAGE)
        }
        catch {
          case ex: Exception => throw HandleStageException(ex.getMessage)
        }
      case area @ HiveArea.HIST =>
        try {
          writeToHiveHist(spark, config.getConfig(area))
          logSuccessEvent(spark, currentTable, EventType.WRITE_TO_HIST)
        }
        catch {
          case ex: Exception => throw HandleHistException(ex.getMessage)
        }
    }
  }

  /** Run writing transformed data to Hive
    *
    * @param spark SparkSession
    * @param config config object with configuration where to write transformed data
    */
  def writeToHive(spark: SparkSession, config: Config): Unit = {
    out("INFO: Start writing to Hive...")
    val hiveTablesConf = config.getConfigList("hive")
    val iterator = hiveTablesConf.iterator()
    while(iterator.hasNext){
      val entry = iterator.next()
      // set currentTable to current table name from config
      out("INFO: |- current table name: " + setTableName(entry))
      // prepare Df and write to Hive (Stage)
      if(entry.hasPath("stage")){
        runWritingToHive(spark, entry, HiveArea.STAGE)
      }
      else {
        out("INFO: Writing to Stage is not configured")
      }
      // prepare Df and write to Hive (Hist)
      if(entry.hasPath("hist")){
        runWritingToHive(spark, entry, HiveArea.HIST)
      }
      else {
        out("INFO: Writing to Hist is not configured")
      }
    }
  }

  def argsToOptionMap(args:Array[String]):Map[String,String]= {
    def nextOption(argList:List[String], map:Map[String, String]) : Map[String, String] = {
      val pattern       = "--(\\w+)".r // Selects Arg from --Arg
      val patternSwitch = "-(\\w+)".r  // Selects Arg from -Arg
      argList match {
        case Nil => map
        case pattern(opt)       :: value  :: tail => nextOption( tail, map ++ Map(opt -> value) )
        case patternSwitch(opt) :: tail => nextOption( tail, map ++ Map(opt -> null) )
        case string             :: Nil  => map ++ Map(string -> null)
        case option             :: tail => {
          out("Unknown option:" + option)
          sys.exit(1)
        }
      }
    }
    nextOption(args.toList,Map())
  }


  // write DataFrame partitioned by 'partitionCol' to HDFS
  def saveToHdfs(df: DataFrame, saveMode: SaveMode, path: String, partitionCol: List[String]): Unit = {
    out("INFO: Writing DataFrame WITH partitions")
    out("INFO: |- partitionCol: " + partitionCol.mkString(", "))
    out("INFO: |- mode:         " + saveMode.toString)
    out("INFO: |- path:         " + path)
    out("INFO: |- Partitions number: " + df.rdd.getNumPartitions)
    df.write.mode(saveMode).partitionBy(partitionCol: _*).format("parquet").save(path)
    out("INFO: Saving to HDFS succedded!")
  }

  // write DataFrame to HDFS
  def saveToHdfs(df: DataFrame, saveMode: SaveMode, path: String): Unit = {
    out("INFO: Writing DataFrame [WITHOUT] partitions")
    out("INFO: |- mode:         " + saveMode.toString)
    out("INFO: |- path:         " + path)
    out("INFO: |- Partitions number: " + df.rdd.getNumPartitions)
    df.write.mode(saveMode).format("parquet").save(path)
    out("INFO: Saving to HDFS succedded!")
  }

  // parse file to Config
  def parseConfig(file: File): Config = {
    val envConfig = ConfigFactory.parseFile(file)
    out("INFO: Configuration was loaded from file: " + file.getPath)
    envConfig
  }

  def loadFile(fname: String): Config = {
    val set_file = new File(fname)
    if (set_file.exists) {
      return parseConfig(set_file)
    }
    throw new Exception("ERROR: Files does not exist: " + fname)
  }

  def getNow(): String = {
    java.time.LocalDateTime.now.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"))
  }

  def out(msg: String): Unit = {
    println(getNow() + "\t" + msg)
  }
}

final case class HandleHiveException(private val message: String = "", private val cause: Throwable = None.orNull) extends Exception (message, cause)
final case class HandleStageException(private val message: String = "", private val cause: Throwable = None.orNull) extends Exception (message, cause)
final case class HandleHistException(private val message: String = "", private val cause: Throwable = None.orNull) extends Exception (message, cause)


// Enum with transactions' types groupes from src_tables.conf
object TransactTypes extends Enumeration {
  type TransactTypes = Value
  val INSERT = "insertType"
  val DELETE = "deleteType"
}

// Enum with rangle of rows' statuses for Hist tables
object RowStatus extends Enumeration {
  type RowStatus = Value
  val IS_ACTIVE = 0
  val IS_DELETED = 1
}

object IsDeletedFlag extends Enumeration  {
  type IsDeletedFlag = Value
  val NAME = "is_deleted"
  val CREATED = "is_deleted_created"
  val MODIFIED = "is_deleted_modified"
}

// event statuses for logging table
object EventStatus extends Enumeration {
  type EventStatus = Value
  val SUCCESS = "success"
  val ERROR = "error"
  val WARN = "warn"
}

// event types for logging table
object EventType extends Enumeration {
  type EventType = Value
  val IMPORT_JSONS = "import_jsons"
  val WRITE_TO_STAGE = "write_to_stage"
  val WRITE_TO_HIST = "write_to_hist"
  val WRITE_TO_HIVE = "write_to_hive"
  val SYS_ERROR = "system_error"
}

// Hive areas
object HiveArea extends Enumeration {
  type HiveStage = Value
  val STAGE = "stage"
  val HIST = "hist"
}

// system variables
object SysVar extends Enumeration {
  type SysVar = Value
  val SYS_DATE_CLOSE = "SYS_DATE_CLOSE" // current operational bank close date
  val SYS_UNIT = "SYS_UNIT"             // unit specified in spark-submit
  val SYS_APP_NAME = "SYS_APP_NAME"     // spark application name
}
